﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCommand) { throw '请先安装 Node.js 24 LTS，并将 node 加入 PATH。' }
$flinNode = $nodeCommand.Source
if (-not (Test-Path -LiteralPath $flinNode)) { throw '请先安装 Node.js 24 LTS，然后重新启动。' }
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'node_modules\express'))) { throw '请先在本目录运行 npm ci 安装依赖。' }
try {
    $flinSettings = Invoke-RestMethod 'http://127.0.0.1:3210/api/settings' -TimeoutSec 2
    $flinExpectedDb = if ($env:FLIN_DB) { [IO.Path]::GetFullPath($env:FLIN_DB) } else { Join-Path $PSScriptRoot 'data\flin.sqlite' }
    if ($flinSettings.db_path -ne $flinExpectedDb) { throw 'FLIN_PORT_CONFLICT' }
    Start-Process 'http://127.0.0.1:3210'
    exit 0
} catch {
    if ($_.Exception.Message -eq 'FLIN_PORT_CONFLICT') { throw '端口3210正在运行其他数据库，请关闭旧服务或按 README 使用其他端口。' }
}
$env:PORT = '3210'
Start-Process 'http://127.0.0.1:3210'
& $flinNode (Join-Path $PSScriptRoot 'server\index.js')
