import { copyFileSync,existsSync,mkdirSync,constants } from 'node:fs';
import { resolve,dirname } from 'node:path';
import { verifyDatabase } from '../server/backup.js';

const [source,destination]=process.argv.slice(2);
if(!source||!destination){console.error('用法：node scripts/restore.js 备份.sqlite 新目标.sqlite');process.exit(1);}
try{
 const src=resolve(source),dest=resolve(destination);
 if(existsSync(dest)||existsSync(dest+'-wal')||existsSync(dest+'-shm'))throw new Error('目标或 WAL 文件已存在，拒绝覆盖。请选择新的目标目录。');
 if(src===dest)throw new Error('备份和目标不能相同');
 verifyDatabase(src);mkdirSync(dirname(dest),{recursive:true});copyFileSync(src,dest,constants.COPYFILE_EXCL);verifyDatabase(dest);
 console.log(`已恢复并校验：${dest}\n原数据库与备份均未修改。设置 FLIN_DB 指向此文件后启动并核对数据。`);
}catch(error){console.error('恢复未完成：'+error.message);process.exit(1);}
