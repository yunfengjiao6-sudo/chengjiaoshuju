﻿$ErrorActionPreference = 'Stop'
$flinRoot = Split-Path $PSScriptRoot -Parent
$flinUrl = 'http://127.0.0.1:3210'
function Test-FlinReady {
    try {
        $settings = Invoke-RestMethod ($flinUrl + '/api/settings') -TimeoutSec 2
        if ($settings.db_path -ne (Join-Path $flinRoot 'data\flin.sqlite')) {
            throw 'FLIN_PORT_CONFLICT'
        }
        return $true
    } catch {
        if ($_.Exception.Message -eq 'FLIN_PORT_CONFLICT') { throw '端口3210正在运行其他数据库，请先关闭该服务。' }
        return $false
    }
}
try {
    if (-not (Test-FlinReady)) {
        $nodeCommand = Get-Command node -ErrorAction SilentlyContinue
        if (-not $nodeCommand) { throw '请先安装 Node.js 24 LTS，并将 node 加入 PATH。' }
        $flinNode = $nodeCommand.Source
        if (-not (Test-Path -LiteralPath $flinNode)) { throw '未找到 Node.js，请安装 Node.js 24 LTS。' }
        $flinLogs = Join-Path $flinRoot 'logs'
        New-Item -ItemType Directory -Path $flinLogs -Force | Out-Null
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
        $env:PORT = '3210'
        $env:FLIN_DB = Join-Path $flinRoot 'data\flin.sqlite'
        $env:FLIN_BACKUPS = Join-Path $flinRoot 'backups'
        $env:FLIN_DEMO = '0'
        $flinProcess = Start-Process -FilePath $flinNode -ArgumentList 'server/index.js' -WorkingDirectory $flinRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $flinLogs "$stamp.log") -RedirectStandardError (Join-Path $flinLogs "$stamp-error.log") -PassThru
        $ready = $false
        for ($i=0; $i -lt 30; $i++) {
            Start-Sleep -Milliseconds 300
            if (Test-FlinReady) { $ready=$true; break }
            if ($flinProcess.HasExited) { break }
        }
        if (-not $ready) { throw "服务未能启动，请查看 $flinLogs 中最新日志。" }
    }
    Start-Process $flinUrl
} catch {
    $shell = New-Object -ComObject WScript.Shell
    $null = $shell.Popup($_.Exception.Message,0,'FLIN 启动提示',16)
    exit 1
}

