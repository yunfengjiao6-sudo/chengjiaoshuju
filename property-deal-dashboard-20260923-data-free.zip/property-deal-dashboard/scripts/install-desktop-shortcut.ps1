﻿$ErrorActionPreference = 'Stop'
$flinRoot = Split-Path $PSScriptRoot -Parent
$flinDesktop = [Environment]::GetFolderPath('Desktop')
$flinPath = Join-Path $flinDesktop 'FLIN 楼盘成交数据库.lnk'
$flinShell = New-Object -ComObject WScript.Shell
try {
    if (-not (Test-Path -LiteralPath $flinPath)) {
        $flinLink = $flinShell.CreateShortcut($flinPath)
        $flinLink.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $flinLink.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $PSScriptRoot 'open-desktop.ps1') + '"'
        $flinLink.WorkingDirectory = $flinRoot
        $flinLink.Description = 'FLIN 楼盘成交数据库'
        $flinLink.WindowStyle = 7
        $flinLink.Save()
    }
    $null = $flinShell.Popup('桌面快捷方式已就绪：FLIN 楼盘成交数据库',0,'FLIN',64)
} catch {
    $null = $flinShell.Popup($_.Exception.Message,0,'FLIN 安装提示',16)
    exit 1
}

