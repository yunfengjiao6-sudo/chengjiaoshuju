# 本地接口

基地址 `http://127.0.0.1:3210/api`。仅允许本机 Host 与同源请求。先 GET `/session` 获取随机生成的会话令牌，POST / PATCH / DELETE 携带 `X-FLIN-Token` 与 `Content-Type: application/json`。令牌不预置到发布包，也不是公网用户认证。

| 接口 | 功能 |
| --- | --- |
| GET `/health`、`/settings` | 状态和当前运行配置 |
| GET / POST `/communities` | 小区列表与建立 |
| PATCH `/communities/:id` | 更新，需当前 version |
| GET `/communities/:id/stats` | 小区统计 |
| GET / POST `/transactions` | 分页查询或创建成交 |
| GET / PATCH / DELETE `/transactions/:id` | 详情、编辑、软删除；写操作需要当前 version |
| POST `/transactions/:id/restore`、`/transactions/:id/merge` | 恢复或合并空字段 |
| GET `/transactions/:id/history` | 修改审计 |
| POST `/parse` | `{ "text": "待解析文字" }`，不保存成交 |
| POST `/recognition/image` | `{ "image": "PNG的base64" }`，本地识别，不保存图片 |
| GET `/recognition/voice/status` | 本地语音依赖状态 |
| POST `/recognition/voice` | `{ "audio": "WAV的base64" }`，本地转写 |
| POST `/parse/voice` | `{ "text": "核对后的文字" }`，整理草稿 |
| GET `/dashboard` | 统计、趋势、分段和近期成交 |
| POST `/import/inspect` | `{ "filename": "your-file.csv", "file": "base64" }`，检查表头 |
| POST `/import/preview` | 上述请求加 mapping，保存预览批次和原始行 |
| POST `/import/commit` | batch_id 和逐行 decisions，确认后原子提交 |
| GET `/export?format=csv` 或 `format=xlsx` | 导出当前筛选下的记录 |
| GET `/export?template=1&format=xlsx` | 仅含表头的空模板 |
| GET / POST `/backups` | 列出/创建本地备份 |
| GET `/backups/:name` | 下载备份 |

创建成交需要已存在的 `community_id`，其他字段未知时留空。API 价格字段单位为万元，`area_sqm` 为平方米。`null` 可清空字段，PATCH 未传入字段保留原值。日期为完整年月日。`price_per_sqm` 等为只读派生字段。

解析返回草稿、warnings、errors、inferred_fields 与 requires_confirmation；识别内容应核对后再提交。重复/版本冲突返回409，校验失败通常返回422。不可自动绕过重复或异常确认；不能把缺失字段猜成真实数据。

导入预览返回 batch_id 和各行；commit 的 decisions 按源文件行号组织，例如 `{ "2": { "action": "create" }, "3": { "action": "skip" } }`。原始行和预览批次本身属于私人业务数据。
