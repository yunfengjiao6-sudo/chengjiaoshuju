# 离线语音依赖

发布包只包含语音界面和适配代码，不包含任何本机运行时、模型、录音或识别结果。日常录音通过标准输入传给本机 whisper.cpp，不启用云语音 API。

Windows x64 使用与现有适配器相容的 whisper.cpp b5130 CPU 发行包和 medium 多语言模型。以下为本项目原依赖记录中的固定来源和 SHA256；安装时应核对下载文件哈希，不匹配则停止。

| 文件 | 来源 | SHA256 |
| --- | --- | --- |
| whisper-bin-x64.zip | https://github.com/ggml-org/whisper.cpp/releases/download/b5130/whisper-bin-x64.zip | f9ec6c52a2e949b62ab51fa21d0d497958f9e41c3010c157c4e42932d5316f3c |
| ggml-medium.bin | https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin | 6c14d5adee5f86394037b4e4e8b59f1673b6cee10e3cf0b11bbdbee79c156208 |

1. 自行从上方来源下载，保留第三方许可文件。模型约1.53GB。
2. 可用 PowerShell `Get-FileHash -Algorithm SHA256 文件路径` 校验。
3. 将发行包的 `Release` 内容（含所需 DLL）放到应用的 `runtime/whisper-b5130/Release/`，使 `whisper-cli.exe` 位于此目录。
4. 将模型放到 `runtime/models/ggml-medium.bin`，再重启应用。
5. 也可通过 `FLIN_WHISPER_EXE` 和 `FLIN_WHISPER_MODEL` 指定自己的绝对路径；不要提交这些私人配置。

先在 `/api/recognition/voice/status` 查看 available，再用自己新录制的非敏感短句试用。可用状态只说明文件存在，不保证依赖、性能与识别质量。数字、小区和面积仍须人工核对。API 只接受经校验的16kHz单声道16bit PCM WAV，网页负责解码转换；最长60秒。

这是可选本地依赖安装，不是把原电脑的 runtime 目录打包。Linux/macOS 如需语音，应自行构建适配的 whisper.cpp 并设置上述变量；截图 OCR 仍需要 Windows。
