import { AppError, empty, textValue, numberValue, MONEY_FIELDS } from './validation.js';
import { DEFAULT_ORIENTATION } from '../public/transaction-defaults.js';

// Import-only labels and evidence reuse the existing transaction/source model.
export function importFields(columns){return {...columns,community_name:'成交小区',room_no:'室号',bedrooms:'居室',area_sqm:'面积(m²)',listing_price:'报价(万)',transaction_price:'成交价(万)',price_per_sqm:'成交单价(万/m²)',property_type:'属性',cycle_days_reported:'周期(天)'};}
export const normalizeHeader=value=>String(value).normalize('NFKC').toLowerCase().replace(/\s/g,'').replace(/万元/g,'万').replace(/平方米|平米|㎡/g,'m2').replace(/[()]/g,'');
const aliases={
 community_name:['小区名称','成交小区'],area_sqm:['面积','建筑面积','面积(m²)','建筑面积(m²)'],
 transaction_price:['成交价','成交金额','成交总价','成交价(万)','成交总价(万)','成交金额(万)','成交价(元)','成交总价(元)'],
 listing_price:['报价','报价(万)','挂牌价','挂牌价(万)','报价(元)','挂牌价(元)'],
 bedrooms:['居室','户型房数'],cycle_days_reported:['周期','成交周期','周期(天)','成交周期(天)'],
 price_per_sqm:['单价','单价(万/m²)','成交单价','成交单价(万/m²)','单价万元/㎡','成交单价万元/㎡','成交单价元每㎡','成交单价(元/m²)','单价(元/m²)'],
 property_type:['属性'],floor_text:['楼层']
};
export function autoMapHeaders(headers,rows,columns){
 const dict=new Map();
 for(const [key,label]of Object.entries({...columns,...importFields(columns)}))for(const name of [key,label,columns[key]])if(name)dict.set(normalizeHeader(name),key);
 for(const [key,names]of Object.entries(aliases))for(const name of names)dict.set(normalizeHeader(name),key);
 const mapping={};
 for(const header of headers){
  let key=dict.get(normalizeHeader(header));
  if(header==='成交周期天'&&headers.includes(columns.cycle_days_reported))continue; // Export contains both reported and derived cycles.
  if(normalizeHeader(header)==='楼层'){
   const values=rows.map(row=>row.raw[header]).filter(v=>!empty(v));
   // Only a uniformly recognisable building+room column is reclassified.
   if(values.length&&values.every(v=>/^\d+号(?:楼)?\d+(?:室)?$/.test(String(v).trim())))key='room_no';
  }
  if(key)mapping[header]=key;
 }
 return mapping;
}
export function parseImportedUnitPrice(value,header=''){
 if(empty(value)||typeof value==='string'&&value.trim().toUpperCase()==='N/A')return null;
 if(!['string','number'].includes(typeof value))throw new AppError('请填写数字或带单位的文本');
 let str=String(value).normalize('NFKC').replace(/\s/g,'').replace(/(?:\/|每)(?:m2|平方米|平米)$/i,'');
 const explicitWan=/万元$|万$/i.test(str),explicitYuan=!explicitWan&&/元$/.test(str);
 str=str.replace(/万元$|万$|元$/,'');
 const h=normalizeHeader(header);
 const yuan=explicitYuan||!explicitWan&&(h==='price_per_sqm'||h.includes('元')&&!h.includes('万'));
 const result=numberValue(str)*(yuan?1:10000);
 if(!Number.isFinite(result)||result<=0)throw new AppError('成交单价必须大于 0');
 return result;
}
const append=(existing,line)=>[textValue(existing),line].filter(Boolean).join('\n');
export function normalizeImportRow(raw,mapping){
 const input={},errors=[];let unitPrice=null,unitHeader=null;
 for(const [header,key]of Object.entries(mapping))if(key){
  let value=raw[header];
  if(MONEY_FIELDS.includes(key)&&!empty(value)&&/^[\d,.+-]+$/.test(String(value).normalize('NFKC').trim())){
   const h=normalizeHeader(header);
   if(h.includes('万'))value=String(value)+'万';else if(h.includes('元'))value=String(value)+'元';
  }
  if(key==='bedrooms'&&typeof value==='string')value=value.trim().normalize('NFKC').replace(/(?:室|房)$/,'');
  if(key==='price_per_sqm'){
   unitHeader=header;
   try{unitPrice=parseImportedUnitPrice(value,header);}catch(error){errors.push(`成交单价：${error.message}`);}
  }else input[key]=value;
 }
 if(!empty(input.property_type))input.notes=append(input.notes,`属性：${textValue(input.property_type)}`);
 delete input.property_type;
 if(empty(input.orientation)){
  input.orientation=DEFAULT_ORIENTATION;
  input.source_detail=append(input.source_detail,'原文件未提供朝向，按用户设置默认南；可编辑修正');
 }
 // Canonical price_per_sqm stays calculated. Source evidence survives edit/export.
 if(unitPrice!==null)input.source_detail=append(input.source_detail,`文件成交单价：${raw[unitHeader]}（列：${unitHeader}；折合 ${Number(unitPrice.toPrecision(12))} 元/㎡）；统计采用成交价/面积计算值`);
 return {input,errors,unitPrice};
}
