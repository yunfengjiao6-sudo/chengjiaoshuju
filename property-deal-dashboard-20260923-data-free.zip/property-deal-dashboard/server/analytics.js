import { buildFilter, findTransactions } from './service.js';
import { today } from './validation.js';

export function median(values){const list=values.filter(v=>v!=null).sort((a,b)=>a-b);const n=list.length;return n?n%2?list[n>>1]:(list[n/2-1]+list[n/2])/2:null;}
const average=values=>{const a=values.filter(v=>v!=null);return a.length?a.reduce((s,n)=>s+n,0)/a.length:null;};
const sum=values=>{const a=values.filter(v=>v!=null);return a.length?a.reduce((s,n)=>s+n,0):null;};
function bucket(rows,field,boundaries,labels){const result=labels.map(label=>({label,count:0}));let unknown=0;for(const row of rows){const n=row[field];if(n==null){unknown++;continue;}let i=boundaries.findIndex(b=>n<b);if(i<0)i=labels.length-1;result[i].count++;}return [...result,{label:'未知',count:unknown}];}
function categories(rows,fn){const values=new Map();for(const row of rows){const label=fn(row)||'未知';values.set(label,(values.get(label)||0)+1);}return [...values].map(([label,count])=>({label,count})).sort((a,b)=>b.count-a.count);}
export function getDashboard(db,query={}) {
 const {where,params}=buildFilter({...query,deleted:'0'});
 const rows=db.prepare(`SELECT id,community_id,community_name,transaction_date,transaction_price,price_per_sqm,
 area_sqm,price_reduction_rate,transaction_cycle_days,bedrooms,floor_category,orientation,building_no,
 quality_status,listing_price FROM transaction_view WHERE ${where}`).all(...params);
 const date=today(),units=rows.map(r=>r.price_per_sqm).filter(v=>v!=null);
 const periods=new Map(),groups=new Map();
 for(const row of rows){
  if(!groups.has(row.community_id))groups.set(row.community_id,[]);groups.get(row.community_id).push(row);
  if(row.transaction_date){let p=row.transaction_date.slice(0,7);if(query.period==='year')p=p.slice(0,4);if(query.period==='quarter')p=`${p.slice(0,4)} Q${Math.ceil(+p.slice(5,7)/3)}`;if(!periods.has(p))periods.set(p,[]);periods.get(p).push(row);}
 }
 const recentFrom=new Date(date+'T00:00:00Z');recentFrom.setUTCDate(recentFrom.getUTCDate()-29);const cutoff=recentFrom.toISOString().slice(0,10);
 const summary={count:rows.length,community_count:groups.size,month_count:rows.filter(r=>r.transaction_date?.startsWith(date.slice(0,7))).length,year_count:rows.filter(r=>r.transaction_date?.startsWith(date.slice(0,4))).length,
 total_amount:sum(rows.map(r=>r.transaction_price)),price_sample:rows.filter(r=>r.transaction_price!=null).length,
 avg_unit_price:average(units),median_unit_price:median(units),unit_sample:units.length,min_unit_price:units.length?Math.min(...units):null,max_unit_price:units.length?Math.max(...units):null,
 avg_area:average(rows.map(r=>r.area_sqm)),avg_discount:average(rows.map(r=>r.price_reduction_rate)),discount_sample:rows.filter(r=>r.price_reduction_rate!=null).length,
 avg_cycle:average(rows.map(r=>r.transaction_cycle_days)),cycle_sample:rows.filter(r=>r.transaction_cycle_days!=null).length,unknown_date:rows.filter(r=>!r.transaction_date).length,last_transaction:rows.map(r=>r.transaction_date).filter(Boolean).sort().at(-1)||null};
 const ranking=[...groups].map(([id,rs])=>({id,name:rs[0].community_name,count:rs.length,total_amount:sum(rs.map(r=>r.transaction_price)),avg_unit_price:average(rs.map(r=>r.price_per_sqm)),median_unit_price:median(rs.map(r=>r.price_per_sqm)),recent_count:rs.filter(r=>r.transaction_date>=cutoff).length}));
 const trends=[...periods].sort(([a],[b])=>a.localeCompare(b)).map(([period,rs])=>({period,count:rs.length,unit_sample:rs.filter(r=>r.price_per_sqm!=null).length,average:average(rs.map(r=>r.price_per_sqm)),median:median(rs.map(r=>r.price_per_sqm)),avg_cycle:average(rs.map(r=>r.transaction_cycle_days)),avg_discount:average(rs.map(r=>r.price_reduction_rate))}));
 const comparison=rows.filter(r=>r.listing_price!=null&&r.transaction_price!=null).sort((a,b)=>(b.transaction_date||'').localeCompare(a.transaction_date||'')).slice(0,20);
 const comparisonDetails=new Map((comparison.length?db.prepare('SELECT * FROM transaction_view WHERE id IN ('+comparison.map(()=>'?').join(',')+')').all(...comparison.map(r=>r.id)):[]).map(r=>[r.id,r]));
 return {summary,ranking,trends,segments:{
  area:bucket(rows,'area_sqm',[50,70,90,120,150],['<50㎡','50–70㎡','70–90㎡','90–120㎡','120–150㎡','150㎡+']),
  price:bucket(rows,'transaction_price',[500,700,1000,1500],['<500万','500–700万','700–1000万','1000–1500万','1500万+']),
  layout:categories(rows,r=>r.bedrooms==null?'未知':r.bedrooms===0?'开间':r.bedrooms>=4?'四房及以上':['','一房','两房','三房'][r.bedrooms]),
  floor:categories(rows,r=>r.floor_category),orientation:categories(rows,r=>r.orientation),building:categories(rows,r=>r.building_no),quality:categories(rows,r=>r.quality_status)},
  recent:findTransactions(db,{...query,deleted:'0',sort:'created_at',page_size:8}).rows,
  listing_comparison:comparison.map(r=>({...comparisonDetails.get(r.id),date:r.transaction_date,listing:r.listing_price,transaction:r.transaction_price})),
  methodology:'均值为每套有效单价的算术平均，中位数按有效单价排序；未知值不参与对应统计。无日期记录计入总量，不计入时间走势。分段左闭右开。少于 5 个样本显示提示。'};
}
