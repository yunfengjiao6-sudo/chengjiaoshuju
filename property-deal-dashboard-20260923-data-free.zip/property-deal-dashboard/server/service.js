import { atomic, audit, now } from './db.js';
import { floorFromRoom } from '../public/property-address.js';
import { withTransactionDefaults } from '../public/transaction-defaults.js';
import { AppError, assertValid, normalizeTransaction, textValue, numberValue, dateValue, MONEY_FIELDS, TX_FIELDS } from './validation.js';

const COMMUNITY_FIELDS=['community_name','district','subdistrict','address','developer','build_year_start','build_year_end','phase','building_count','household_count','property_company','property_fee','parking_info','notes'];
export function listCommunities(db) {
 return db.prepare(`SELECT c.*,COUNT(t.id) AS transaction_count,AVG(t.price_per_sqm) AS avg_unit_price,MAX(t.transaction_date) AS last_transaction
 FROM communities c LEFT JOIN transaction_view t ON t.community_id=c.id AND t.deleted_at IS NULL GROUP BY c.id ORDER BY c.community_name`).all()
 .map(c=>({...c,alias_names:db.prepare('SELECT name FROM community_names WHERE community_id=? AND is_alias=1').all(c.id).map(n=>n.name)}));
}
export function resolveCommunity(db,name) {return db.prepare('SELECT community_id AS id FROM community_names WHERE name=?').get(String(name||'').trim())?.id;}
export function saveCommunity(db,input,id=null) {
 return atomic(db,()=>{
  const old=id?db.prepare('SELECT * FROM communities WHERE id=?').get(id):null;
  if(id&&!old)throw new AppError('小区不存在',404);
  if(old&&Number(input.version)!==old.version)throw new AppError('小区已被修改，请刷新后重试',409);
  const data={...old,...input};
  const values=COMMUNITY_FIELDS.map(key=>{
   if(['build_year_start','build_year_end','building_count','household_count','property_fee'].includes(key)){
    const v=numberValue(data[key]);
    if(v!==null&&(v<0||v>10000000||(key!=='property_fee'&&!Number.isInteger(v))))throw new AppError('小区数字字段无效',422);
    if(key.startsWith('build_year')&&v!==null&&(v<1800||v>2200))throw new AppError('建成年份无效',422);
    return v;
   }
   const v=textValue(data[key]);if(v&&v.length>5000)throw new AppError('小区字段过长',422);return v;
  });
  if(!values[0])throw new AppError('请填写小区名称',422);
  if(data.build_year_start&&data.build_year_end&&+data.build_year_start>+data.build_year_end)throw new AppError('建成年份起止顺序错误',422);
  const previousAliases=id?db.prepare('SELECT name FROM community_names WHERE community_id=? AND is_alias=1').all(id).map(r=>r.name):[];
  const aliases=Array.isArray(data.alias_names)?data.alias_names:String(data.alias_names??previousAliases.join('，')).split(/[,，\n]/);
  if(aliases.some(s=>typeof s!=='string'))throw new AppError('小区别名须为文本列表',422);
  const names=[...new Set([values[0],...aliases.map(s=>s.trim()).filter(Boolean)])];
  for(const name of names){const owner=resolveCommunity(db,name);if(owner&&owner!==id)throw new AppError(`名称或别名“${name}”已被其他小区使用`,409);}
  const stamp=now();
  if(!id) id=Number(db.prepare(`INSERT INTO communities(${COMMUNITY_FIELDS.join(',')},created_at,updated_at) VALUES(${[...values,stamp,stamp].map(()=>'?').join(',')})`).run(...values,stamp,stamp).lastInsertRowid);
  else {
   db.prepare(`UPDATE communities SET ${COMMUNITY_FIELDS.map(f=>`${f}=?`).join(',')},updated_at=?,version=version+1 WHERE id=?`).run(...values,stamp,id);
   COMMUNITY_FIELDS.forEach((f,i)=>{if(old[f]!==values[i])audit(db,'community',id,f,old[f],values[i],input.change_reason||'编辑小区');});
  }
  db.prepare('DELETE FROM community_names WHERE community_id=?').run(id);
  names.forEach((name,i)=>db.prepare('INSERT INTO community_names VALUES(?,?,?)').run(name,id,i?1:0));
  audit(db,'community',id,old?'alias_names':'create',old?previousAliases:null,old?names.slice(1):Object.fromEntries(COMMUNITY_FIELDS.map((f,i)=>[f,values[i]])),input.change_reason||'维护小区');
  return {...db.prepare('SELECT * FROM communities WHERE id=?').get(id),alias_names:names.slice(1)};
 });
}
export function getTransaction(db,id,includeDeleted=false) {
 const row=db.prepare(`SELECT * FROM transaction_view WHERE id=? ${includeDeleted?'':'AND deleted_at IS NULL'}`).get(id);
 if(!row)throw new AppError('成交记录不存在',404);
 return row;
}
export function checkDuplicateTransaction(db,data,excludeId=0) {
 const clauses=['community_id=?','deleted_at IS NULL','id<>?'],params=[data.community_id,excludeId];
 const signals=[];
 if(data.area_sqm!=null){signals.push('ABS(area_sqm-?)<=0.1');params.push(data.area_sqm);}
 if(data.transaction_price!=null){signals.push('ABS(transaction_price-?)<=0.1');params.push(data.transaction_price);}
 if(data.transaction_date){signals.push('transaction_date=?');params.push(data.transaction_date);}
 if(data.room_no&&data.building_no){signals.push('(room_no=? AND building_no=?)');params.push(data.room_no,data.building_no);}
 if(signals.length<1)return [];
 clauses.push(`(${signals.join(' OR ')})`);
 const candidates=db.prepare(`SELECT * FROM transaction_view WHERE ${clauses.join(' AND ')} ORDER BY id DESC`).all(...params);
 return candidates.map(row=>({...row,...duplicateAssessment(data,row)})).filter(row=>row.duplicate_score>=4).sort((a,b)=>b.duplicate_score-a.duplicate_score).slice(0,20);
}
export function duplicateAssessment(data,row){
  if(data.community_id!==row.community_id)return {duplicate_score:0,duplicate_reasons:[]};
  const reasons=[];let score=0;
  if(data.area_sqm!=null&&row.area_sqm!=null&&Math.abs(row.area_sqm-data.area_sqm)<=0.1){score+=2;reasons.push('面积相近');}
  if(data.transaction_price!=null&&row.transaction_price!=null&&Math.abs(row.transaction_price-data.transaction_price)<=0.1){score+=2;reasons.push('成交价相近');}
  if(data.transaction_date&&row.transaction_date===data.transaction_date){score+=2;reasons.push('成交日期相同');}
  if(data.building_no&&data.room_no&&row.building_no===data.building_no&&row.room_no===data.room_no){score+=4;reasons.push('楼栋室号相同');}
  // A different known transaction date can represent a legitimate resale.
  if(data.transaction_date&&row.transaction_date&&data.transaction_date!==row.transaction_date)score-=3;
  return {duplicate_score:score,duplicate_reasons:reasons};
}
function storedData(data) {
 return Object.fromEntries(TX_FIELDS.filter(f=>!['source','source_detail','original_text'].includes(f)).map(f=>MONEY_FIELDS.includes(f)?[`${f}_fen`,data[f]==null?null:Math.round(data[f]*1e6)]:[f,data[f]??null]));
}
export function createTransaction(db,input,options={}) {
 return atomic(db,()=>{
  const data=assertValid(normalizeTransaction(withTransactionDefaults(input)),options.confirm_warnings);
  const community=db.prepare('SELECT * FROM communities WHERE id=?').get(data.community_id);
  if(!community)throw new AppError('小区不存在，请先建立小区',422);
  const duplicates=checkDuplicateTransaction(db,data);
  if(duplicates.length&&options.allow_duplicate!==true)throw new AppError('发现疑似重复成交',409,{duplicates});
  const stamp=now();
  const sourceId=Number(db.prepare('INSERT INTO sources(source_type,source_detail,original_text,import_batch_id,created_at) VALUES(?,?,?,?,?)')
   .run(data.source,data.source_detail,data.original_text,options.import_batch_id||null,stamp).lastInsertRowid);
  const stored={...storedData(data),community_name_snapshot:community.community_name,source_id:sourceId,created_at:stamp,updated_at:stamp};
  const id=Number(db.prepare(`INSERT INTO transactions(${Object.keys(stored).join(',')}) VALUES(${Object.keys(stored).map(()=>'?').join(',')})`).run(...Object.values(stored)).lastInsertRowid);
  audit(db,'transaction',id,'create',null,data,options.allow_duplicate?'用户确认仍然新增':options.import_batch_id?'批量导入':'新增成交');
  audit(db,'transaction',id,'raw_input',null,Object.fromEntries(TX_FIELDS.filter(f=>Object.hasOwn(input,f)).map(f=>[f,input[f]])),'保留未经规范化的输入');
  return getTransaction(db,id);
 });
}
export function updateTransaction(db,id,input,options={}) {
 return atomic(db,()=>{
  const old=getTransaction(db,id);
  if(Number(input.version)!==old.version)throw new AppError('记录已被其他操作修改，请重新打开后编辑',409,{current:old});
  const merged={...old,...input};
  const roomChanged=Object.hasOwn(input,'room_no')&&textValue(input.room_no)!==textValue(old.room_no);
  const followsRoom=roomChanged&&!old.floor_text&&old.floor_number===floorFromRoom(old.room_no)&&(!Object.hasOwn(input,'floor_number')||textValue(input.floor_number)===textValue(old.floor_number));
  if(followsRoom)merged.floor_number=null;
  const floorChanged=followsRoom||['floor_number','total_floors','floor_text'].some(f=>Object.hasOwn(input,f)&&textValue(input[f])!==textValue(old[f]));
  const previouslyDerived=normalizeTransaction({...old,floor_category:null}).data.floor_category;
  if(floorChanged&&previouslyDerived&&previouslyDerived===old.floor_category&&(!Object.hasOwn(input,'floor_category')||input.floor_category===old.floor_category))merged.floor_category=null;
  const normalized=normalizeTransaction(merged);
  const data=assertValid(normalized,options.confirm_warnings);
  if(!db.prepare('SELECT id FROM communities WHERE id=?').get(data.community_id))throw new AppError('小区不存在',422);
  const duplicates=checkDuplicateTransaction(db,data,id);
  if(duplicates.length&&options.allow_duplicate!==true)throw new AppError('修改后的记录与已有成交疑似重复',409,{duplicates});
  const stored=storedData(data);
  db.prepare(`UPDATE transactions SET ${Object.keys(stored).map(f=>`${f}=?`).join(',')},updated_at=?,version=version+1 WHERE id=?`).run(...Object.values(stored),now(),id);
  db.prepare('UPDATE sources SET source_type=?,source_detail=?,original_text=? WHERE id=?').run(data.source,data.source_detail,data.original_text,old.source_id);
  TX_FIELDS.forEach(f=>{if(old[f]!==data[f])audit(db,'transaction',id,f,old[f],data[f],input.change_reason||'编辑成交');});
  audit(db,'transaction',id,'raw_input',null,Object.fromEntries(TX_FIELDS.filter(f=>Object.hasOwn(input,f)).map(f=>[f,input[f]])),input.change_reason||'保留编辑时的原始输入');
  return getTransaction(db,id);
 });
}
export function mergeTransaction(db,id,input,options={}) {
 return atomic(db,()=>{
  const old=getTransaction(db,id);const normalized=assertValid(normalizeTransaction({...old,...input}),options.confirm_warnings);
  if(normalized.community_id!==old.community_id)throw new AppError('不能合并不同小区的成交',422);
  const patch={version:input.version,change_reason:'合并：仅补充空字段'},conflicts=[];
  for(const field of TX_FIELDS){
   if(!Object.hasOwn(input,field)||normalized[field]==null)continue;
   if(old[field]==null)patch[field]=normalized[field];
   else if(old[field]!==normalized[field]&&!['original_text','source','source_detail'].includes(field))conflicts.push(field);
  }
  if(conflicts.length)throw new AppError('合并存在字段冲突，请查看记录后手动编辑',409,{conflicts});
  const result=updateTransaction(db,id,patch,{...options,allow_duplicate:true});
  audit(db,'transaction',id,'merge_input',null,input,'保留合并来源原文');
  return result;
 });
}
export function setDeleted(db,id,version,deleted=true,options={}) {
 return atomic(db,()=>{
  const old=getTransaction(db,id,true);
  if(Number(version)!==old.version)throw new AppError('记录已更新，请刷新后重试',409);
  if(!deleted&&old.deleted_at&&options.allow_duplicate!==true){const duplicates=checkDuplicateTransaction(db,old,id);if(duplicates.length)throw new AppError('恢复后将产生疑似重复成交，请先核对',409,{duplicates});}
  const value=deleted?now():null;
  db.prepare('UPDATE transactions SET deleted_at=?,updated_at=?,version=version+1 WHERE id=?').run(value,now(),id);
  audit(db,'transaction',id,'deleted_at',old.deleted_at,value,deleted?'用户确认移入回收站':'从回收站恢复');
  return getTransaction(db,id,true);
 });
}
export function buildFilter(query={}) {
 const clauses=[query.deleted==='1'?'deleted_at IS NOT NULL':'deleted_at IS NULL'],params=[];
 const add=(sql,v)=>{clauses.push(sql);params.push(v);};
 for(const f of ['community_id','bedrooms'])if(query[f]!==undefined&&query[f]!==''){const n=numberValue(query[f]);if(!Number.isInteger(n)||n<0)throw new AppError('筛选条件无效');add(`${f}=?`,n);}
 for(const f of ['floor_category','orientation','quality_status'])if(query[f])add(`${f}=?`,query[f]);
 const ranges={};
 for(const [key,col,op] of [['date_from','transaction_date','>='],['date_to','transaction_date','<='],['area_min','area_sqm','>='],['area_max','area_sqm','<='],['price_min','transaction_price','>='],['price_max','transaction_price','<='],['unit_min','price_per_sqm','>='],['unit_max','price_per_sqm','<=']])if(query[key]!==undefined&&query[key]!==''){
  try{const v=key.startsWith('date')?dateValue(query[key]):numberValue(query[key]);if(v===null||typeof v==='number'&&v<0)throw new Error('范围必须是非负数');ranges[key]=v;add(`${col}${op}?`,v);}catch(error){throw new AppError(`筛选条件无效：${error.message}`,422);}
 }
 for(const [from,to,label]of [['date_from','date_to','日期'],['area_min','area_max','面积'],['price_min','price_max','总价'],['unit_min','unit_max','单价']])if(ranges[from]!==undefined&&ranges[to]!==undefined&&ranges[from]>ranges[to])throw new AppError(`${label}范围的起点不能大于终点`,422);
 if(query.q){
  const q=String(query.q).trim();
  if(q.length>200)throw new AppError('搜索词过长');
  if(/^\d+(?:\.\d+)?\s*(?:平|㎡|平米|m²)$/i.test(q)) {add('ABS(area_sqm-?)<=0.5',numberValue(q,'area'));}
  else if(/^\d+(?:\.\d+)?\s*(?:万|w|万元)$/i.test(q))add('ABS(transaction_price-?)<=0.1',numberValue(q,'money'));
  else {
   const pattern='%'+q.replace(/[!%_]/g,'!$&')+'%';
   clauses.push("(community_name LIKE ? ESCAPE '!' OR building_no LIKE ? ESCAPE '!' OR room_no LIKE ? ESCAPE '!' OR (COALESCE(building_no,'')||CASE WHEN building_no GLOB '*[0-9]' THEN '号' ELSE '' END||COALESCE(room_no,'')) LIKE ? ESCAPE '!' OR transaction_date LIKE ? ESCAPE '!' OR notes LIKE ? ESCAPE '!' OR community_id IN (SELECT community_id FROM community_names WHERE name LIKE ? ESCAPE '!'))");
   params.push(...Array(7).fill(pattern));
  }
 }
 return {where:clauses.join(' AND '),params};
}
export function findTransactions(db,query={}) {
 const {where,params}=buildFilter(query);
 for(const key of ['page','page_size'])if(query[key]!==undefined&&query[key]!==''&&(!Number.isSafeInteger(Number(query[key]))||Number(query[key])<1))throw new AppError('页码和每页条数须为正整数',422);
 const sortable=['transaction_date','community_name','area_sqm','transaction_price','price_per_sqm','created_at','updated_at','bedrooms','listing_price','price_reduction_rate','transaction_cycle_days','id','building_no','room_no','floor_number','floor_category','orientation','source','quality_status','notes'];
 const sort=query.sort==='address'?"COALESCE(building_no,'')||COALESCE(room_no,'')":sortable.includes(query.sort)?query.sort:'transaction_date';const order=query.order==='asc'?'ASC':'DESC';
 const page=Math.max(1,Math.floor(Number(query.page)||1)),pageSize=Math.min(50000,Math.max(1,Math.floor(Number(query.page_size)||25)));
 const total=db.prepare(`SELECT COUNT(*) AS n FROM transaction_view WHERE ${where}`).get(...params).n;
 const rows=db.prepare(`SELECT * FROM transaction_view WHERE ${where} ORDER BY ${sort} ${order} NULLS LAST,id DESC LIMIT ? OFFSET ?`).all(...params,pageSize,(page-1)*pageSize);
 return {rows,total,page,page_size:pageSize};
}
export function getHistory(db,id) {getTransaction(db,id,true);return db.prepare("SELECT * FROM audit_logs WHERE record_type='transaction' AND record_id=? ORDER BY id DESC").all(id);}
