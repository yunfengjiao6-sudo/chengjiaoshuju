import { backup, DatabaseSync } from 'node:sqlite';
import { mkdirSync, readdirSync, statSync, unlinkSync, existsSync, renameSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';

export function listBackups(dir){mkdirSync(dir,{recursive:true});return readdirSync(dir).filter(n=>/^(auto|manual)-[\w-]+\.sqlite$/.test(n)).map(name=>({name,size:statSync(join(dir,name)).size,created_at:statSync(join(dir,name)).mtime.toISOString()})).sort((a,b)=>b.created_at.localeCompare(a.created_at));}
export function verifyDatabase(path){const check=new DatabaseSync(path,{readOnly:true});try{if(check.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw new Error('备份完整性检查失败');if(check.prepare('PRAGMA foreign_key_check').all().length)throw new Error('备份外键检查失败');if(!check.prepare("SELECT name FROM sqlite_master WHERE name='schema_migrations'").get())throw new Error('不是 FLIN 数据库');}finally{check.close();}}
export async function createBackup(db,dir,kind='manual'){
 mkdirSync(dir,{recursive:true});
 const filename=`${kind}-${new Date().toISOString().replace(/[:.]/g,'-')}-${randomUUID().slice(0,8)}.sqlite`;
 const temporary=join(dir,filename+'.partial'),target=join(dir,filename);
 await backup(db,temporary);verifyDatabase(temporary);renameSync(temporary,target);
 if(kind==='auto'){
  const expired=listBackups(dir).filter(f=>f.name.startsWith('auto-')).slice(14);
  for(const item of expired){const path=resolve(dir,item.name);if(path.startsWith(resolve(dir)+ '\\')||path.startsWith(resolve(dir)+'/'))unlinkSync(path);}
 }
 return {name:filename,size:statSync(target).size,verified:true};
}
export function safeBackupPath(dir,name){if(!listBackups(dir).some(b=>b.name===name))return null;const path=join(dir,name);return existsSync(path)?path:null;}
