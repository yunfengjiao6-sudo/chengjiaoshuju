import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDatabase } from './db.js';
import { createApp } from './app.js';
import { createBackup } from './backup.js';

const root=fileURLToPath(new URL('../',import.meta.url));
const dbPath=resolve(process.env.FLIN_DB||resolve(root,'data/flin.sqlite'));
const backupDir=resolve(process.env.FLIN_BACKUPS||resolve(root,'backups'));
const port=Number(process.env.PORT||3210);
const db=openDatabase(dbPath);
const app=createApp(db,{dbPath,backupDir,demo:process.env.FLIN_DEMO==='1'});
try{await createBackup(db,backupDir,'auto');}catch(error){console.error('启动备份失败，停止启动以保护数据：',error.message);db.close();process.exit(1);}
const server=app.listen(port,'127.0.0.1',()=>console.log(`FLIN 楼盘成交数据库：http://127.0.0.1:${port}\n数据库：${dbPath}`));
server.on('error',error=>{console.error(error.code==='EADDRINUSE'?'端口已占用，请打开已有服务或设置 PORT 使用其他端口':error);db.close();process.exit(1);});
const timer=setInterval(()=>createBackup(db,backupDir,'auto').catch(error=>console.error('自动备份失败：',error.message)),24*60*60*1000);timer.unref();
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{clearInterval(timer);server.close(()=>{db.close();process.exit(0);});});
