import ExcelJS from 'exceljs';
import { parse } from 'csv-parse/sync';
import { randomUUID } from 'node:crypto';
import { atomic, now } from './db.js';
import { AppError, normalizeTransaction } from './validation.js';
import { importFields, autoMapHeaders, normalizeImportRow } from './import-normalization.js';
import { resolveCommunity, checkDuplicateTransaction, duplicateAssessment, createTransaction, mergeTransaction, buildFilter } from './service.js';

export const COLUMNS={community_name:'小区',transaction_date:'成交日期',area_sqm:'面积㎡',transaction_price:'成交价万',listing_price:'挂牌价万',final_listing_price:'最后挂牌价万',listing_date:'挂牌日期',building_no:'楼栋',unit_no:'单元',room_no:'室号',bedrooms:'房',living_rooms:'厅',bathrooms:'卫',floor_text:'楼层原文',floor_number:'所在楼层',total_floors:'总楼层',floor_category:'楼层分类',orientation:'朝向',elevator:'电梯',building_year:'建成年份',layout_type:'户型类型',decoration:'装修',cycle_days_reported:'填报周期天',source:'来源',source_detail:'来源详情',data_confidence:'核实状态',notes:'备注',original_text:'原始输入'};
const EXPORT_DERIVED={id:'记录ID',price_per_sqm:'成交单价元每㎡',price_reduction_amount:'议价金额万',price_reduction_rate:'议价率',transaction_cycle_days:'成交周期天',quality_status:'数据质量',created_at:'创建时间',updated_at:'更新时间'};
export const IMPORT_FIELDS=importFields(COLUMNS);
// Validate ZIP metadata before ExcelJS inflates the workbook, bounding local file resource use.
function validateWorkbookArchive(buffer){
 let end=-1;
 for(let i=buffer.length-22;i>=Math.max(0,buffer.length-65557);i--)if(buffer.readUInt32LE(i)===0x06054b50){end=i;break;}
 if(end<0)throw new AppError('不是有效的 XLSX 压缩文件',422);
 const count=buffer.readUInt16LE(end+10);let pos=buffer.readUInt32LE(end+16),total=0;
 if(count>2000||pos===0xffffffff)throw new AppError('Excel 内部文件过多或格式过大，请另存精简版本',422);
 for(let i=0;i<count;i++){
  if(pos+46>buffer.length||buffer.readUInt32LE(pos)!==0x02014b50)throw new AppError('Excel 压缩目录损坏',422);
  total+=buffer.readUInt32LE(pos+24);
  if(total>64*1024*1024)throw new AppError('Excel 解压后超过 64 MB，请拆分并移除无用样式或图片',413);
  pos+=46+buffer.readUInt16LE(pos+28)+buffer.readUInt16LE(pos+30)+buffer.readUInt16LE(pos+32);
 }
}
function cellValue(cell){const v=cell.value;if(v==null)return '';if(v instanceof Date)return v.toISOString().slice(0,10);if(typeof v==='object'){if(v.formula||v.sharedFormula)throw new AppError('Excel 含公式，请先粘贴为值后导入',422);if(v.richText)return v.richText.map(t=>t.text).join('');if(v.text)return v.text;throw new AppError('Excel 包含不支持的单元格类型',422);}if(Number.isInteger(v)&&v>=0&&/^0{2,}$/.test(cell.numFmt||''))return String(v).padStart(cell.numFmt.length,'0');return v;}
export async function readTabular(buffer,filename,sheetName=null){
 if(buffer.length>10*1024*1024)throw new AppError('文件不能超过 10 MB',413);
 let matrix,sheets=[];
 if(/\.xlsx$/i.test(filename)){
  validateWorkbookArchive(buffer);
  const workbook=new ExcelJS.Workbook();
  try{await workbook.xlsx.load(buffer);}catch{throw new AppError('无法读取 Excel，请提供有效的 .xlsx 文件',422);}
  sheets=workbook.worksheets.map(w=>w.name);
  const sheet=sheetName?workbook.getWorksheet(sheetName):workbook.worksheets[0];
  if(!sheet)throw new AppError('Excel 工作表不存在',422);
  if(sheet.rowCount>5001||sheet.columnCount>100)throw new AppError('每批最多 5000 行、100 列，请拆分文件',422);
  matrix=[];sheet.eachRow({includeEmpty:true},row=>{const arr=[];for(let i=1;i<=sheet.columnCount;i++)arr.push(cellValue(row.getCell(i)));matrix.push(arr);});
 }else if(/\.csv$/i.test(filename)){
  let str;try{str=new TextDecoder('utf-8',{fatal:true}).decode(buffer);}catch{try{str=new TextDecoder('gb18030',{fatal:true}).decode(buffer);}catch{throw new AppError('CSV 编码无法识别，请保存为 UTF-8',422);}}
  try{matrix=parse(str,{bom:true,skip_empty_lines:false,relax_column_count:true,max_record_size:100000});}catch{throw new AppError('CSV 格式错误，请检查引号和分隔符',422);}
 }else throw new AppError('仅支持 .csv 和 .xlsx；旧 .xls 请另存为 .xlsx',422);
 if(!matrix?.length)throw new AppError('文件为空',422);
 const headers=matrix[0].map(h=>String(h??'').trim());
 if(headers.length>100||matrix.length>5001)throw new AppError('每批最多 5000 行、100 列',422);
 if(!headers.length||headers.some(h=>!h)||new Set(headers).size!==headers.length)throw new AppError('列名不能为空或重复，请检查第一行表头',422);
 const rows=matrix.slice(1).map((cells,i)=>({row_number:i+2,cells,raw:Object.fromEntries(headers.map((h,j)=>[h,cells[j]??'']))}));
 const mapping=autoMapHeaders(headers,rows,COLUMNS);
 return {headers,rows,mapping,sheets,preview:rows.slice(0,8).map(r=>r.raw)};
}
export function previewImport(db,tabular,mapping,filename){
 const targetFields=Object.values(mapping).filter(Boolean);
 if(!targetFields.includes('community_name'))throw new AppError('请至少映射“小区”列',422);
 if(new Set(targetFields).size!==targetFields.length)throw new AppError('不能将多个列映射到同一字段',422);
 if(targetFields.some(k=>!Object.hasOwn(IMPORT_FIELDS,k)))throw new AppError('存在不支持的字段映射',422);
 if(Object.keys(mapping).some(k=>!tabular.headers.includes(k)))throw new AppError('映射中包含不存在的表头',422);
 const id=randomUUID();
 return atomic(db,()=>{
  db.prepare('INSERT INTO import_batches(id,filename,mapping,created_at) VALUES(?,?,?,?)').run(id,filename,JSON.stringify(mapping),now());
  const rows=[],seen=new Map();
  for(const row of tabular.rows){
   const empty=row.cells.every(v=>v===null||v===undefined||String(v).trim()==='');
   const normalized=normalizeImportRow(row.raw,mapping),input=normalized.input;
   input.community_id=resolveCommunity(db,input.community_name);
   input.original_text=JSON.stringify(row.raw);input.source=input.source||'历史导入';
   const result=normalizeTransaction(input);
   result.errors.push(...normalized.errors);
   const calculated=result.data.transaction_price&&result.data.area_sqm?result.data.transaction_price*10000/result.data.area_sqm:null;
   // 0.005 万/㎡ is the half-step rounding allowance for a two-decimal source.
   if(normalized.unitPrice!==null&&calculated!==null&&Math.abs(normalized.unitPrice-calculated)>50.000001)result.warnings.push('文件成交单价与成交价/面积计算结果不一致，请核对');
   if(normalized.unitPrice!==null&&(normalized.unitPrice<1000||normalized.unitPrice>500000))result.warnings.push('文件成交单价超出常见范围，请核对');
   if(!input.community_id&&!empty)result.errors.unshift(`小区“${input.community_name||''}”未建立，请先建立小区及别名后重新预览`);
   if(row.cells.length>tabular.headers.length)result.errors.push('本行列数超过表头，可能存在未加引号的逗号');
   if(empty)result.errors.splice(0,result.errors.length,'空白行，需明确跳过');
   const duplicates=result.errors.length?[]:checkDuplicateTransaction(db,result.data);
   const previous=seen.get(result.data.community_id)||[];
   const batchDuplicate=result.errors.length?null:previous.find(r=>duplicateAssessment(result.data,r.data).duplicate_score>=4)?.row_number;
   if(!result.errors.length){previous.push({data:result.data,row_number:row.row_number});seen.set(result.data.community_id,previous);}
   const status=result.errors.length?'error':duplicates.length||batchDuplicate?'duplicate':'new';
   const item={row_number:row.row_number,data:result.data,price_per_sqm:normalized.unitPrice,calculated_price_per_sqm:calculated,community_name:input.community_name,errors:result.errors,warnings:result.warnings,duplicates,batch_duplicate:batchDuplicate||null,status};
   rows.push(item);
   db.prepare('INSERT INTO import_rows VALUES(?,?,?,?,?,?)').run(id,row.row_number,JSON.stringify(row.raw),JSON.stringify(result.data),JSON.stringify(result.errors),JSON.stringify(result.warnings));
  }
  return {batch_id:id,rows,counts:{new:rows.filter(r=>r.status==='new').length,duplicate:rows.filter(r=>r.status==='duplicate').length,error:rows.filter(r=>r.status==='error').length},filename};
 });
}
export function commitImport(db,id,decisions){
 return atomic(db,()=>{
  const batch=db.prepare('SELECT * FROM import_batches WHERE id=?').get(id);
  if(!batch)throw new AppError('预览批次不存在',404);
  if(batch.status==='committed')return {...JSON.parse(batch.result),idempotent:true};
  if(!decisions||typeof decisions!=='object')throw new AppError('请为每行确认导入或跳过',422);
  const result={batch_id:id,created:0,merged:0,skipped:0,records:[]};
  for(const row of db.prepare('SELECT * FROM import_rows WHERE batch_id=? ORDER BY row_number').all(id)){
   const decision=decisions[row.row_number];
   if(!decision||!['skip','create','force','merge'].includes(decision.action))throw new AppError(`第 ${row.row_number} 行尚未选择处理方式`,422);
   if(decision.action==='skip'){result.skipped++;continue;}
   if(JSON.parse(row.errors_json).length)throw new AppError(`第 ${row.row_number} 行有错误，只能跳过或修正后重新预览`,422);
   const warnings=JSON.parse(row.warnings_json);
   if(warnings.length&&decision.confirm_warnings!==true)throw new AppError(`第 ${row.row_number} 行：请确认异常数据后再保存`,422,{warnings,confirmation_required:true});
   const data=JSON.parse(row.data_json),options={import_batch_id:id,confirm_warnings:decision.confirm_warnings===true,allow_duplicate:decision.action==='force'};
   try{
    let record;
    if(decision.action==='merge'){
     const candidates=checkDuplicateTransaction(db,data);
     if(!candidates.some(c=>c.id===Number(decision.target_id)))throw new AppError('合并目标不在重复候选中',422);
     record=mergeTransaction(db,Number(decision.target_id),{...data,version:decision.version},options);result.merged++;
    }else{record=createTransaction(db,data,options);result.created++;}
    result.records.push({row_number:row.row_number,id:record.id});
   }catch(error){error.message=`第 ${row.row_number} 行：${error.message}`;throw error;}
  }
  db.prepare("UPDATE import_batches SET status='committed',result=?,committed_at=? WHERE id=?").run(JSON.stringify(result),now(),id);
  return result;
 });
}
const safeCsv=value=>{const str=value==null?'':String(value);return '"'+(typeof value==='string'&&/^[\s]*[=+\-@\t\r]/.test(str)?"'"+str:str).replaceAll('"','""')+'"';};
export async function exportTransactions(db,query,format='csv',template=false){
 const columns=template?COLUMNS:{...COLUMNS,...EXPORT_DERIVED};
 const {where,params}=buildFilter(query);
 const rows=template?[]:db.prepare(`SELECT * FROM transaction_view WHERE ${where} ORDER BY transaction_date DESC NULLS LAST,id DESC`).all(...params);
 if(format==='xlsx'){
  const workbook=new ExcelJS.Workbook();workbook.creator='FLIN';
  const sheet=workbook.addWorksheet('成交记录');sheet.columns=Object.entries(columns).map(([key,header])=>({key,header,width:key==='original_text'?50:18}));
  rows.forEach(row=>sheet.addRow(Object.fromEntries(Object.keys(columns).map(key=>[key,row[key]??null]))));
  sheet.getRow(1).font={bold:true,color:{argb:'FFFFFFFF'}};sheet.getRow(1).fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF14584E'}};
  sheet.views=[{state:'frozen',ySplit:1}];sheet.autoFilter={from:'A1',to:{row:1,column:Object.keys(columns).length}};
  return Buffer.from(await workbook.xlsx.writeBuffer());
 }
 return Buffer.from('\uFEFF'+[Object.values(columns).map(safeCsv).join(','),...rows.map(r=>Object.keys(columns).map(k=>safeCsv(r[k])).join(','))].join('\r\n'),'utf8');
}
