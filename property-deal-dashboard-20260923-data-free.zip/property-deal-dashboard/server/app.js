import express from 'express';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AppError } from './validation.js';
import { listCommunities,saveCommunity,createTransaction,updateTransaction,findTransactions,getTransaction,checkDuplicateTransaction,mergeTransaction,setDeleted,getHistory } from './service.js';
import { getDashboard } from './analytics.js';
import { parseQuickEntry } from './parser.js';
import { IMPORT_FIELDS,readTabular,previewImport,commitImport,exportTransactions } from './import-export.js';
import { createBackup,listBackups,safeBackupPath } from './backup.js';
import { createImageRecognitionService } from './recognition/image-service.js';
import { createSpeechService } from './speech/service.js';
import { speechDraft } from './speech/draft.js';

const publicDir=fileURLToPath(new URL('../public',import.meta.url));
export function createApp(db,{dbPath,backupDir,demo=false,recognitionProvider,speechProvider}={}) {
 const app=express(),token=randomBytes(32).toString('hex');
 const imageRecognition=createImageRecognitionService(recognitionProvider);
 const speech=createSpeechService(speechProvider);
 app.disable('x-powered-by');
 app.use((req,res,next)=>{
  const host=req.headers.host||'';
  if(!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(host))return res.status(403).json({error:'仅允许本机访问'});
  if(req.headers.origin&&req.headers.origin!==`http://${host}`)return res.status(403).json({error:'不允许跨站访问本地数据'});
  res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"});
  if(req.path.startsWith('/api/'))res.set('Cache-Control','no-store');
  if(['POST','PATCH','DELETE','PUT'].includes(req.method)){
   const incoming=Buffer.from(req.get('X-FLIN-Token')||'');const expected=Buffer.from(token);
   if(incoming.length!==expected.length||!timingSafeEqual(incoming,expected))return res.status(403).json({error:'会话令牌失效，请刷新页面'});
  }
  next();
 });
 app.use(express.json({limit:'15mb'}));
 app.get('/api/session',(req,res)=>res.json({token,demo,version:'1.0.0'}));
 app.get('/api/health',(req,res)=>res.json({ok:db.prepare('SELECT 1 AS ok').get().ok===1}));
 app.get('/api/communities',(req,res)=>res.json(listCommunities(db)));
 app.post('/api/communities',(req,res)=>res.status(201).json(saveCommunity(db,req.body)));
 app.patch('/api/communities/:id',(req,res)=>res.json(saveCommunity(db,req.body,+req.params.id)));
 app.get('/api/communities/:id/stats',(req,res)=>{
  const community=listCommunities(db).find(c=>c.id===+req.params.id);if(!community)throw new AppError('小区不存在',404);
  res.json({community,...getDashboard(db,{...req.query,community_id:community.id})});
 });
 app.get('/api/transactions',(req,res)=>res.json(findTransactions(db,req.query)));
 app.get('/api/transactions/:id',(req,res)=>res.json(getTransaction(db,+req.params.id,req.query.deleted==='1')));
 app.get('/api/transactions/:id/history',(req,res)=>res.json(getHistory(db,+req.params.id)));
 app.post('/api/transactions',(req,res)=>res.status(201).json(createTransaction(db,req.body,req.body.options||{})));
 app.patch('/api/transactions/:id',(req,res)=>res.json(updateTransaction(db,+req.params.id,req.body,req.body.options||{})));
 app.post('/api/transactions/:id/merge',(req,res)=>res.json(mergeTransaction(db,+req.params.id,req.body,req.body.options||{})));
 app.delete('/api/transactions/:id',(req,res)=>res.json(setDeleted(db,+req.params.id,req.body.version,true)));
 app.post('/api/transactions/:id/restore',(req,res)=>res.json(setDeleted(db,+req.params.id,req.body.version,false,req.body.options||{})));
 app.post('/api/parse',(req,res)=>{if(typeof req.body.text!=='string'||req.body.text.length>30000)throw new AppError('原文须为不超过 30000 字的文本');res.json(parseQuickEntry(req.body.text,listCommunities(db)));});
 app.post('/api/recognition/image',async(req,res)=>res.json(await imageRecognition.recognizeTransactionImage(req.body,listCommunities(db))));
 app.get('/api/recognition/voice/status',(req,res)=>res.json(speech.status()));
 app.post('/api/recognition/voice',async(req,res)=>res.json(await speech.recognize(req.body,listCommunities(db))));
 app.post('/api/parse/voice',(req,res)=>res.json(speechDraft(req.body?.text,listCommunities(db),{method:'edited-voice-transcript'})));
 app.get('/api/dashboard',(req,res)=>res.json(getDashboard(db,req.query)));
 async function readUpload(body){if(typeof body.file!=='string'||typeof body.filename!=='string')throw new AppError('缺少文件');return readTabular(Buffer.from(body.file,'base64'),body.filename,body.sheet);}
 app.post('/api/import/inspect',async(req,res)=>{const t=await readUpload(req.body);res.json({headers:t.headers,mapping:t.mapping,sheets:t.sheets,preview:t.preview,row_count:t.rows.length,fields:IMPORT_FIELDS});});
 app.post('/api/import/preview',async(req,res)=>res.json(previewImport(db,await readUpload(req.body),req.body.mapping||{},req.body.filename)));
 app.post('/api/import/commit',(req,res)=>res.json(commitImport(db,req.body.batch_id,req.body.decisions)));
 app.get('/api/import/batches',(req,res)=>res.json(db.prepare('SELECT id,filename,status,result,created_at,committed_at FROM import_batches ORDER BY created_at DESC LIMIT 50').all()));
 app.get('/api/export',async(req,res)=>{
  const format=req.query.format==='xlsx'?'xlsx':'csv';
  const data=await exportTransactions(db,req.query,format,req.query.template==='1');
  res.set({'Content-Type':format==='xlsx'?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="flin-${req.query.template==='1'?'template':'transactions'}.${format}"`});res.send(data);
 });
 app.get('/api/backups',(req,res)=>res.json(listBackups(backupDir)));
 let backupBusy=false;
 app.post('/api/backups',async(req,res)=>{if(backupBusy)throw new AppError('备份正在进行',409);backupBusy=true;try{res.json(await createBackup(db,backupDir));}finally{backupBusy=false;}});
 app.get('/api/backups/:name',(req,res)=>{const path=safeBackupPath(backupDir,req.params.name);if(!path)throw new AppError('备份不存在',404);res.download(path,{dotfiles:'allow'});});
 app.get('/api/settings',(req,res)=>res.json({db_path:resolve(dbPath),backup_path:resolve(backupDir),schema_version:1,version:'1.0.0',demo,sqlite_version:db.prepare('SELECT sqlite_version() AS v').get().v,auto_backup_retention:14,manual_backup_retention:'永久保留',runtime:process.version}));
 app.use(express.static(publicDir,{etag:true}));
 app.use('/api',(req,res)=>res.status(404).json({error:'接口不存在'}));
 app.use((error,req,res,next)=>{
  if(res.headersSent)return next(error);
  const status=error.status||500;
  if(status>=500)console.error(error);
  res.status(status).json({error:status>=500?'操作未完成，请查看本地服务日志；本次事务已回滚':error.message,...(error.details||{})});
 });
 return app;
}
