// Preserve column boundaries and pair vertically stacked labels only by local geometry.
// Original OCR remains separately available; no digit or label guessing is done here.
const normalize=text=>String(text).normalize('NFKC').replace(/[ \t]+/g,'').replace(/(?<=\d)[·。](?=\d)/g,'.').replace(/(\d{4})[一—–](\d{1,2})[一—–](\d{1,2})/g,'$1-$2-$3');
const money=/^[+-]?\d[\d,.]*(?:万元|万|w|元)$/i;
const labels={
 '成交总价':money,'成交价':money,'成交价格':money,'挂牌价':money,'初始挂牌价':money,'最后挂牌价':money,
 '建筑面积':/^\d+(?:[.,]\d+)?(?:m2|㎡|平|平方米)?$/i,'面积':/^\d+(?:[.,]\d+)?(?:m2|㎡|平|平方米)?$/i,
 '成交日期':/^\d{4}[-/.年]\d{1,2}[-/.月]\d{1,2}日?$/,'挂牌日期':/^\d{4}[-/.年]\d{1,2}[-/.月]\d{1,2}日?$/,
 '挂牌周期':/^\d+天$/,'成交周期':/^\d+天$/,'成交单价':/^\d[\d,.]*元(?:\/.*)?$/,'单价':/^\d[\d,.]*元(?:\/.*)?$/,
 '户型':/^(?:\d|[一二两三四五六七八九十])[室房].*$/,'楼层':/^(?:低|中|高)(?:楼层|层|区).*$/,'朝向':/^[东西南北通透]+$/
};
export function layoutText(result){
 if(!result.lines?.length)return normalize(result.text||'');
 const segments=[];
 for(const line of result.lines){
  if(!line.words?.length){segments.push({text:normalize(line.text)});continue;}
  let words=[];
  const emit=()=>{if(!words.length)return;const x=Math.min(...words.map(w=>w.x)),y=Math.min(...words.map(w=>w.y));segments.push({text:normalize(words.map(w=>w.text).join('')),x,y,width:Math.max(...words.map(w=>w.x+w.width))-x,height:Math.max(...words.map(w=>w.y+w.height))-y});words=[];};
  for(const word of line.words){const last=words.at(-1);if(last&&word.x-(last.x+last.width)>Math.max(45,word.height*2))emit();words.push(word);}emit();
 }
 const consumed=new Set(),paired=new Map();
 for(const label of segments){
  const key=label.text.replace(/[：:]$/,'');if(!labels[key]||!Number.isFinite(label.y))continue;
  const candidates=segments.filter(s=>s!==label&&!consumed.has(s)&&Number.isFinite(s.y)&&labels[key].test(s.text)&&Math.abs(s.x-label.x)<=Math.max(20,label.height*.9)&&Math.abs(s.y-label.y)>label.height*.4&&Math.abs(s.y-label.y)<Math.max(label.height,s.height)*3.6).sort((a,b)=>Math.abs(a.y-label.y)-Math.abs(b.y-label.y));
  // An ambiguous adjacent pair stays unpaired; do not select a different card's number.
  if(candidates.length===1||(candidates.length>1&&Math.abs(candidates[1].y-label.y)>Math.abs(candidates[0].y-label.y)*1.6)){
   const value=candidates[0];paired.set(label,key+value.text);consumed.add(value);
  }
 }
 return segments.filter(s=>!consumed.has(s)).map(s=>paired.get(s)||s.text).join('\n');
}
