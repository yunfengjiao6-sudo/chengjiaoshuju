import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {AppError} from '../validation.js';

const script=fileURLToPath(new URL('./windows-ocr.ps1',import.meta.url));
export class WindowsOcrProvider {
 name='windows-ocr-zh';
 async recognize(image) {
  if(process.platform!=='win32')throw new AppError('本地识别需要 Windows 10/11 和简体中文 OCR 语言包',422);
  return new Promise((resolve,reject)=>{
   const child=spawn(join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe'),['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script],{windowsHide:true,stdio:['pipe','pipe','pipe']});
   let output='',diagnostic='',settled=false;
   const done=(error,result)=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve(result);};
   const timer=setTimeout(()=>{child.kill();done(new AppError('识别超时，请裁剪到单套成交信息后重试',422));},25000);
   child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');
   child.stdout.on('data',chunk=>{output+=chunk.toString('utf8');if(output.length>3000000){child.kill();done(new AppError('图片文字过多，请裁剪后重试',422));}});
   // Only provider error codes are logged; image and extracted personal text are never logged.
   child.stderr.on('data',chunk=>{diagnostic+=chunk.toString('utf8').slice(0,500);});
   child.on('error',()=>done(new AppError('本地识别服务不可用，请检查 Windows PowerShell',422)));
   child.stdin.on('error',()=>{});
   child.on('close',code=>{if(code!==0){console.error('[OCR provider]',diagnostic.includes('OCR_LANGUAGE_MISSING')?'OCR_LANGUAGE_MISSING':'OCR_FAILED');return done(new AppError(diagnostic.includes('OCR_LANGUAGE_MISSING')?'未安装简体中文 OCR，请在 Windows 语言设置中安装中文文字识别功能':'图片无法识别，请换用清晰、正向的单套成交截图',422));}try{done(null,JSON.parse(output.replace(/^\uFEFF/,'')));}catch{done(new AppError('识别服务返回异常，请重试',422));}});
   child.stdin.end(JSON.stringify({image:image.toString('base64')}));
  });
 }
}
