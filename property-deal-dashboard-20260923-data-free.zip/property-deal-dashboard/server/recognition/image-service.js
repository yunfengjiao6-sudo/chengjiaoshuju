import {AppError,normalizeTransaction,numberValue} from '../validation.js';
import {parseQuickEntry} from '../parser.js';
import {WindowsOcrProvider} from './windows-provider.js';
import {layoutText} from './layout-text.js';

const MAX_BYTES=8*1024*1024;
export function validateImagePayload(payload){
 const value=payload?.image;
 if(typeof value!=='string'||value.length>Math.ceil(MAX_BYTES/3)*4)throw new AppError('图片过大，识别图片不能超过8MB',413);
 if(!value.length||value.length%4!==0||!/^[A-Za-z0-9+/]+={0,2}$/.test(value))throw new AppError('图片数据无效，请重新选择图片',422);
 const bytes=Buffer.from(value,'base64');
 if(bytes.length<24||!bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))||bytes.toString('ascii',12,16)!=='IHDR')throw new AppError('请通过选图、粘贴或拖放传入有效图片',422);
 const width=bytes.readUInt32BE(16),height=bytes.readUInt32BE(20);
 if(!width||!height||width>2600||height>2600||width*height>6000000)throw new AppError('图片尺寸过大，请裁剪为单套房源截图',413);
 return bytes;
}
export function redactOcrText(text){return text.split('\n').map(line=>/^(?:联系人|客户姓名|业主姓名|经纪人|联系电话|手机号)/.test(line.replace(/\s/g,''))?'[无关个人信息已隐藏]':line).join('\n').replace(/(?:\+?86[- ]?)?1[ -]?[3-9](?:[ -]?\d){9}\b/g,'[手机号已隐藏]').replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g,'[邮箱已隐藏]').replace(/\b\d{17}[\dXx]\b/g,'[证件号已隐藏]');}
export function prepareOcrText(result){
 return layoutText(result).replace(/((?:建筑)?面积[:：]?\d+),(\d{1,2})(?=\D|$)/g,'$1.$2');
}
const canonical=name=>String(name).normalize('NFKC').replace(/\s/g,'').replace(/小区$/,'');
export function matchImageCommunity(text,communities){
 const lines=text.split('\n').map(s=>s.replace(/^(?:小区名称|小区|楼盘)[：:]?/,''));
 let candidates=communities.filter(c=>[c.community_name,...c.alias_names].some(name=>lines.some(line=>canonical(line)===canonical(name))));
 if(!candidates.length)candidates=communities.filter(c=>[c.community_name,...c.alias_names].some(name=>canonical(name).length>=4&&lines.some(line=>line.includes(canonical(name)))));
 const strong=candidates.length>0;
 if(!strong){const near=(a,b)=>a.length===b.length&&a.length>=4&&[...a].filter((ch,i)=>ch!==b[i]).length===1;candidates=communities.filter(c=>[c.community_name,...c.alias_names].some(n=>lines.some(line=>near(canonical(line),canonical(n)))));}
 return {selected:strong&&candidates.length===1?candidates[0].id:null,candidates:candidates.map(c=>({id:c.id,name:c.community_name,match:strong?'名称/别名匹配':'近似名称，请核对'})),ambiguous:!strong||candidates.length!==1};
}
export function extractImageDraft(result,communities,{method='windows-ocr-zh',timestamp=new Date().toISOString()}={}){
 const prepared=prepareOcrText(result),raw=redactOcrText((result.lines||[]).map(l=>l.text).join('\n')||result.text||'');
 if(prepared.length>30000)throw new AppError('文字过多，请裁剪为单套房源截图',422);
 const parsed=parseQuickEntry(prepared,communities,{strictDates:true,strictEvidence:true});
 parsed.warnings.unshift('已整理OCR字间空格和数字分隔符，请对照原图核对小数点、日期和金额。');
 const match=matchImageCommunity(prepared,communities);parsed.data.community_id=match.selected;
 const repeatedPrices=[...prepared.matchAll(/成交(?:总价|价格|价)?[：:]?([+-]?\d[\d,.]*(?:万元|万|W|w|元))/g)];
 const repeatedAreas=[...prepared.matchAll(/(?:建筑面积[：:]?|面积[：:]?)(\d[\d.]*)/g)];
 const explicitAreas=[...prepared.matchAll(/(\d[\d.,]*)(?:㎡|m2|平米|平方米|平)(?!方)/gi)];
 const namedLines=new Set(prepared.split('\n').filter(line=>match.candidates.some(c=>canonical(line)===canonical(c.name))).map(canonical));
 const multi=repeatedPrices.length>1||repeatedAreas.length>1||new Set(explicitAreas.map(m=>m[1])).size>1||namedLines.size>1;
 const unitMatch=prepared.match(/(?:成交单价|单价)[：:]?(\d[\d,.]*)元?(?:\/|每)?(?:m2|平|平方米|㎡)?/i);
 const recognized={};if(unitMatch){try{recognized.price_per_sqm=numberValue(unitMatch[1]);}catch{parsed.warnings.push('截图单价格式异常，请核对原图');}}
 const rateMatch=prepared.match(/(?:议价率|降价幅度)[：:]?(-?\d+(?:\.\d+)?)%/);if(rateMatch)recognized.price_reduction_rate=Number(rateMatch[1])/100;
 if(parsed.data.cycle_days_reported!=null)recognized.transaction_cycle_days=parsed.data.cycle_days_reported;
 parsed.data.source='截图识别';parsed.data.source_detail=`${method} · ${timestamp} · 未知截图来源`;
 parsed.data.original_text=raw;parsed.data.data_confidence='待核实';
 if(parsed.inferred_fields.includes('transaction_date'))delete parsed.data.transaction_date;
 const normalized=normalizeTransaction(parsed.data);
 const clean={...normalized.data};
 // Invalid recognized values stay visible for correction; they must never silently turn into NULL.
 for(const [key,value]of Object.entries(parsed.data))if(value!=null&&clean[key]===undefined)clean[key]=value;
 if(multi){parsed.warnings.push('截图可能包含多套成交或多个冲突数值，请裁剪为单套房源后重新识别');}
 const {area_sqm:a,transaction_price:p,listing_price:l,transaction_date:td,listing_date:ld}=normalized.data;
 const derived={price_per_sqm:a>0&&p>0?p*10000/a:null,price_reduction_rate:l>0&&p>0?(l-p)/l:null,transaction_cycle_days:td&&ld?Math.round((Date.parse(td)-Date.parse(ld))/86400000):null};
 if(recognized.price_per_sqm!=null&&derived.price_per_sqm!=null&&Math.abs(recognized.price_per_sqm-derived.price_per_sqm)>Math.max(100,derived.price_per_sqm*.01))parsed.warnings.push('截图单价与系统计算结果不一致，请核对。');
 if(recognized.price_reduction_rate!=null&&derived.price_reduction_rate!=null&&Math.abs(recognized.price_reduction_rate-derived.price_reduction_rate)>.005)parsed.warnings.push('截图议价率与系统计算结果不一致，请核对。');
 if(recognized.transaction_cycle_days!=null&&derived.transaction_cycle_days!=null&&recognized.transaction_cycle_days!==derived.transaction_cycle_days)parsed.warnings.push('截图周期与日期计算结果不一致，请核对。');
 const propertyEvidence=match.candidates.length>0||/建筑面积|成交(?:总价|价格|价|日期|时间)/.test(prepared);
 const meaningful=propertyEvidence&&['area_sqm','transaction_price','transaction_date'].some(k=>parsed.data[k]!=null);
 if(!meaningful)parsed.warnings.push('无法识别有效成交信息，请裁剪或换用更清晰的截图');
 const uncertain=normalized.errors.length||multi||!meaningful||parsed.warnings.some(w=>w.includes('不一致'))||normalized.warnings.length;
 const fields=Object.fromEntries(Object.entries(clean).filter(([k,v])=>v!=null&&!['original_text','source','source_detail','data_confidence'].includes(k)).map(([key,value])=>[key,{value,status:uncertain?'LOW':'MEDIUM',reason:'本地OCR不提供字段准确率，请逐项核对原图'}]));
 return {...parsed,data:clean,errors:[...parsed.errors,...normalized.errors],warnings:[...new Set([...parsed.warnings,...normalized.warnings,'所有识别字段均须人工核对；截图未提供的内容留空。'])],image_recognition:{method,timestamp,raw_text:raw,prepared_text:redactOcrText(prepared),fields,recognized,derived,community_matches:match.candidates,blocked:multi||!meaningful,width:result.width,height:result.height,retained_image:false},original_text:raw};
}
export function createImageRecognitionService(provider=new WindowsOcrProvider()){
 let busy=false;
 return {async recognizeTransactionImage(payload,communities){const image=validateImagePayload(payload);if(busy)throw new AppError('正在识别另一张图片，请稍后重试',429);busy=true;try{return extractImageDraft(await provider.recognize(image),communities,{method:provider.name});}finally{busy=false;}}};
}
