import { today,dateValue } from './validation.js';

// Parser interface: parse(text, communities) -> {data, warnings, inferred_fields, original_text}.
// Any future LLM adapter must use the same preview and service validation path.
export function parseQuickEntry(raw,communities,{strictDates=false,strictEvidence=false}={}) {
 const normalizedText=String(raw||'').normalize('NFKC').replace(/−/g,'-');
 // OCR layout already pairs labels with values. Never cross a remaining card boundary.
 const text=strictEvidence?normalizedText.replace(/\r?\n/g,'；'):normalizedText;
 const data={original_text:String(raw||''),source:'用户提供'},warnings=[],inferred_fields=[];
 const names=communities.flatMap(c=>[c.community_name,...(c.alias_names||[])].map(name=>({name,id:c.id}))).sort((a,b)=>b.name.length-a.name.length);
 const matches=names.filter(n=>text.includes(n.name));
 const ids=[...new Set(matches.map(n=>n.id))];
 if(ids.length===1)data.community_id=ids[0];else warnings.push(ids.length?'识别到多个小区，请选择正确小区':'未匹配小区，请先建立或选择小区');
 const capture=(key,re,fn=Number)=>{const m=text.match(re);if(m)data[key]=fn(m[1]);};
 capture('area_sqm',/([+-]?\d[\d.,]*)\s*(?:平方米|平米|平|㎡|m2)/i,s=>s.includes(',')?s:Number(s));
 if(data.area_sqm===undefined)capture('area_sqm',/(?:建筑面积|建筑面積|面积)[：: \t]*([+-]?\d[\d.,]*)(?![\d./-])/,s=>s.includes(',')?s:Number(s));
 const cn={'零':0,'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10};
 const layoutText=text.replace(/(?:室号|房号)[：:\s]*[\w-]+(?:室|房)?/g,'');
 for(const [key,unit] of [['bedrooms','房|室'],['living_rooms','厅'],['bathrooms','卫']]){const m=layoutText.match(new RegExp(`(\\d+|[零一二两三四五六七八九十])(?:${unit})`));if(m)data[key]=cn[m[1]]??Number(m[1]);}
 capture('floor_text',/((?:低|中|高)(?:楼层|区|层))/,String);
 capture('floor_number',/(?:楼层[:：]?\s*)?(-?\d+)\s*\/\s*\d+\s*层/);
 capture('total_floors',/-?\d+\s*\/\s*(\d+)\s*层/);
 if(data.total_floors===undefined)capture('total_floors',/(?:总楼层[：:\s]*|共)(\d+)\s*层/);
 if(data.floor_number===undefined)capture('floor_number',/(?:所在楼层|楼层)[：:\s]*(-?\d+)\s*(?:楼|层)/);
 capture('building_no',/(?:楼栋[：:\s]*)([\w-]+)/,String);
 if(data.building_no===undefined)capture('building_no',/(\d+)号楼/,String);
 capture('unit_no',/(\d+)单元/,String);
 capture('room_no',/(?:室号|房号)[：:\s]*([\w-]+)/,String);
 capture('building_year',/(?:建成年份|建成年代|建筑年代)[：:\s]*(\d{4})/);
 capture('decoration',/(毛坯|简装|精装|豪装)/,String);
 capture('elevator',/(?:电梯)[：:\s]*(有|无)/,s=>s==='有'?1:0);
 capture('orientation',/(南北通透|南北通|南北|东南|西南|东北|西北|东西|朝南|朝北|朝东|朝西|南向|北向|东向|西向)/,s=>s.replace(/朝|向/g,'').replace(/通透|通/g,''));
 if(!data.orientation)capture('orientation',/(?:^|[，,\s])([东南西北])(?=$|[，,\s。])/,String);
 const money='([+-]?[0-9][0-9,.]*\\s*(?:万元|万|[wW]|元))';
 capture('transaction_price',new RegExp('成交(?:价|价格|总价)?[：:\\s]*'+money),String);
 if(!data.transaction_price)capture('transaction_price',new RegExp(money+'[ \\t]*(?:成交|售出)'),String);
 capture('final_listing_price',new RegExp('最后挂牌(?:价)?[：:\\s]*'+money),String);
 capture('listing_price',new RegExp('(?<!最后)挂牌(?:价)?[：:\\s]*'+money),String);
 if(!strictEvidence&&!data.transaction_price&&!data.listing_price&&!data.final_listing_price){
  const prices=[...text.matchAll(new RegExp(money,'g'))].filter(m=>!/^\s*(?:\/|每)/.test(text.slice(m.index+m[0].length)));
  if(prices.length===1&&/成交/.test(text))data.transaction_price=prices[0][1];
 }
 capture('cycle_days_reported',/(?:挂牌周期|成交周期|挂牌)\s*[:：]?\s*(\d+)\s*天/);
 const full='(\\d{4}[-/.年]\\d{1,2}[-/.月]\\d{1,2}日?)';
 capture('transaction_date',new RegExp('成交(?:日期|时间)[：:\\s]*'+full),String);
 capture('listing_date',new RegExp('挂牌(?:日期)?[：:\\s]*'+full),String);
 if(!data.listing_date){const match=text.match(new RegExp(full+'[ \\t]*挂牌'));if(match&&match[1]!==data.transaction_date)data.listing_date=match[1];}
 if(!data.transaction_date)capture('transaction_date',new RegExp(full+'\\s*成交'),String);
 if(!data.transaction_date&&!strictDates){
  const dates=[...text.matchAll(new RegExp(full,'g'))];
  if(dates.length===1&&!data.listing_date){data.transaction_date=dates[0][1];inferred_fields.push('transaction_date');warnings.push('原文日期用途未明确，暂填成交日期，请确认');}
 }
 if(!data.transaction_date&&!strictDates){
  const dateText=text.replace(new RegExp(full,'g'),'').replace(/挂牌(?:日期)?[：:\s]*\d{1,2}月\d{1,2}日|\d{1,2}月\d{1,2}日\s*挂牌/g,'');
  const short=dateText.match(/(\d{1,2})月(\d{1,2})日/);
  if(short){data.transaction_date=`${today().slice(0,4)}-${short[1].padStart(2,'0')}-${short[2].padStart(2,'0')}`;inferred_fields.push('transaction_date');warnings.push('原文日期缺少年份，暂按本年填写，请确认年份');}
  else if(/今天.*成交|成交.*今天/.test(text)){data.transaction_date=today();inferred_fields.push('transaction_date');warnings.push('“今天”已按上海本机日期转换，请确认');}
 }
 if(!data.transaction_date)warnings.push('未提供完整成交日期，保留未知');
 if(!data.area_sqm)warnings.push('未识别面积，保留未知');
 if(!data.transaction_price)warnings.push('未识别成交价，保留未知');
 warnings.push('请核对识别结果；未识别的信息仍保存在原文中');
 const errors=[],invalid_fields=[];
 for(const [key,label]of [['transaction_date','成交日期'],['listing_date','挂牌日期']])if(data[key]){
  try{data[key]=dateValue(data[key]);}catch(error){errors.push(`${label}无效，请手动重新填写：${data[key]}`);invalid_fields.push(key);}
 }
 return {data,warnings,errors,invalid_fields,inferred_fields,original_text:raw,parser:'deterministic-v1',requires_confirmation:true};
}
