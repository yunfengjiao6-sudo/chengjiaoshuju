import {AppError} from '../validation.js';
import {WhisperProvider} from './whisper-provider.js';
import {speechDraft} from './draft.js';
export function validateAudio(payload){
 const encoded=payload?.audio;if(typeof encoded!=='string'||encoded.length>2700000)throw new AppError('录音过大，请控制在60秒以内',413);
 if(encoded.length%4||!/^[A-Za-z0-9+/]+={0,2}$/.test(encoded))throw new AppError('录音数据无效',422);
 const b=Buffer.from(encoded,'base64');
 if(b.length<44||b.toString('ascii',0,4)!=='RIFF'||b.toString('ascii',8,12)!=='WAVE'||b.readUInt32LE(4)+8!==b.length)throw new AppError('请使用有效的WAV录音',422);
 let format=null,samples=null;
 for(let p=12;p+8<=b.length;){const id=b.toString('ascii',p,p+4),size=b.readUInt32LE(p+4),start=p+8;if(start+size>b.length)throw new AppError('录音文件损坏',422);
  if(id==='fmt '){if(format||size<16)throw new AppError('录音格式无效',422);format={codec:b.readUInt16LE(start),channels:b.readUInt16LE(start+2),rate:b.readUInt32LE(start+4),byteRate:b.readUInt32LE(start+8),block:b.readUInt16LE(start+12),bits:b.readUInt16LE(start+14)};}
  if(id==='data'){if(samples)throw new AppError('录音数据重复',422);samples=b.subarray(start,start+size);}p=start+size+(size%2);
 }
 if(!format||format.codec!==1||format.channels!==1||format.rate!==16000||format.bits!==16||format.block!==2||format.byteRate!==32000||!samples||samples.length%2)throw new AppError('录音需为16kHz单声道PCM；请通过页面录音或上传转换',422);
 const duration=samples.length/32000;if(duration<.3||duration>60)throw new AppError('请录制0.3至60秒语音',422);
 let power=0;for(let p=0;p<samples.length;p+=2){const n=samples.readInt16LE(p)/32768;power+=n*n;}
 if(Math.sqrt(power/(samples.length/2))<.003)throw new AppError('未检测到清晰声音，请靠近麦克风重录',422);
 return b;
}
export function createSpeechService(provider=new WhisperProvider()){
 let busy=false;
 return {status:()=>({available:provider.available?.()??true,method:provider.name,local_processing:true,max_seconds:60,audio_retained:false}),async recognize(payload,communities){if(busy)throw new AppError('语音服务正在处理上一段录音，请稍后重试',429);const audio=validateAudio(payload);busy=true;try{const result=await provider.recognize(audio);return speechDraft(result.text,communities,{method:provider.name,warnings:result.warnings});}finally{audio.fill(0);busy=false;}}};
}
