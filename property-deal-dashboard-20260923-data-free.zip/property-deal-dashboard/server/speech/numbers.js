// Speech-specific lexical normalization only. Field extraction stays in parser.js.
import {toSimplifiedChinese} from './chinese.js';
const digits={'零':0,'〇':0,'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9};
export function chineseNumber(text){
 if(!text||!/^[零〇一二两三四五六七八九十百千万亿点]+$/.test(text))return null;
 const parts=text.split('点');if(parts.length>2||parts[1]==='')return null;
 const integer=parts[0];let value=0;
 if(/^[零〇一二两三四五六七八九]+$/.test(integer))value=Number([...integer].map(c=>digits[c]).join(''));
 else{
  let section=0,num=null,lastUnit=10000,zero=false;
  for(const ch of integer){
   if(ch in digits){if(num!==null&&num!==0)return null;num=digits[ch];if(num===0)zero=true;continue;}
   const unit={十:10,百:100,千:1000,万:10000,亿:100000000}[ch];if(!unit)return null;
   if(unit>=10000){if(section===0&&num===null)return null;value+=(section+(num||0))*unit;section=0;num=null;lastUnit=10000;zero=false;}
   else{if(unit>=lastUnit)return null;if(num===null&&unit!==10)return null;section+=(num??1)*unit;num=null;lastUnit=unit;zero=false;}
  }
  // “七百二” may mean 720 or 702; do not guess omitted units.
  if(num&&lastUnit>=100&&!zero)return null;
  value+=section+(num||0);
 }
 if(parts.length===2){if(!/^[零〇一二两三四五六七八九]+$/.test(parts[1]))return null;value+=Number('0.'+[...parts[1]].map(c=>digits[c]).join(''));}
 return Number.isFinite(value)&&value<=1e12?Number(value.toFixed(8)):null;
}
export function normalizeSpeechNumbers(raw){
 const warnings=[];
 let text=toSimplifiedChinese(String(raw)).normalize('NFKC').replace(/负/g,'-');
 if(/坪/.test(text))warnings.push('转写含“坪”，与平方米不是同一单位，请核对并手动修改面积；系统不会自动换算或按谐音填写。');
 const cn='[零〇一二两三四五六七八九十百千万亿点]+';
 text=text.replace(/(成交单价|单价)[：:\s]*([零〇一二两三四五六七八九十百千万亿点]+)(?![零〇一二两三四五六七八九十百千万亿点])/g,(all,label,num)=>{const n=chineseNumber(num);return n===null?all:label+n+'元/㎡';});
 text=text.replace(new RegExp(`(${cn})(?=万(?:元)?(?![零〇一二两三四五六七八九十百千万亿点0-9])|元|平方米|平米|平|m2|房|室|厅|卫|天|号楼|单元|层|月|日|号|年|%)`,'g'),(match)=>{const n=chineseNumber(match);if(n===null){warnings.push(`“${match}”数值含糊，请手动确认`);return match;}return String(n);});
 text=text.replace(/(\d{1,2}月\d{1,2})号/g,'$1日');
 return {text,warnings};
}
