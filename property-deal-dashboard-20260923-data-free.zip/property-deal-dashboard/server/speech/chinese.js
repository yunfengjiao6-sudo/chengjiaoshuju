import {Converter} from 'opencc-js/t2cn';

// Pure local dictionary conversion; no speech correction or number rewriting.
// Construct once so the dictionaries are reused for every transcript.
const convert=Converter({from:'t',to:'cn'});
export const toSimplifiedChinese=text=>convert(text);
