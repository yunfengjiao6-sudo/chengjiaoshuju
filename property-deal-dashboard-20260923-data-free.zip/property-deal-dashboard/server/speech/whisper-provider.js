import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {isAbsolute,dirname,basename} from 'node:path';
import {fileURLToPath} from 'node:url';
import {AppError} from '../validation.js';
const bundledExecutable=fileURLToPath(new URL('../../runtime/whisper-b5130/Release/whisper-cli.exe',import.meta.url));
const bundledModel=fileURLToPath(new URL('../../runtime/models/ggml-medium.bin',import.meta.url));
export class WhisperProvider{
 name='offline-whisper';
 constructor({executable=process.env.FLIN_WHISPER_EXE||bundledExecutable,model=process.env.FLIN_WHISPER_MODEL||bundledModel,timeout=180000}={}){this.executable=executable;this.model=model;this.timeout=timeout;const variant=String(model||'').match(/ggml-(small|medium|large[^/\\]*?)\.bin$/)?.[1];if(variant)this.name+='-'+variant;}
 available(){return !!(this.executable&&this.model&&isAbsolute(this.executable)&&isAbsolute(this.model)&&existsSync(this.executable)&&existsSync(this.model));}
 async recognize(audio){
  if(!this.available())throw new AppError('离线语音模型尚未配置，请上传音频稍后重试，或使用文字录入',503);
  return new Promise((resolve,reject)=>{
   // WAV via stdin: no raw-audio temporary file or transcript output file.
   // An explicit unused output basename avoids CLI's special '-' stdout-format mode.
   // No --output-* flag is enabled, so only stdout is produced and no file is created.
   const child=spawn(this.executable,['-m',basename(this.model),'-f','-','-of','memory-only','-l','zh','-t','4','-ng','-np','-nt','--prompt','以下是普通话房产信息，请使用简体中文。'],{cwd:dirname(this.model),windowsHide:true,stdio:['pipe','pipe','pipe']});
   let output='',settled=false;
   const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve(value);};
   const timer=setTimeout(()=>{child.kill();finish(new AppError('语音识别超时，请缩短至30秒内重试',422));},this.timeout);
   child.stdout.setEncoding('utf8');child.stdout.on('data',part=>{output+=part;if(output.length>30000){child.kill();finish(new AppError('识别内容过长，请分段录入',422));}});
   child.stderr.on('data',()=>{}); // Native diagnostics can contain transcript fragments; never log them.
   child.stdin.on('error',()=>{});child.on('error',()=>finish(new AppError('离线语音程序无法启动，请检查服务配置',503)));
   child.on('close',code=>code===0?finish(null,{text:output.trim(),warnings:[]}):finish(new AppError('语音识别失败，请换用清晰录音重试',422)));
   child.stdin.end(audio);
  });
 }
}
