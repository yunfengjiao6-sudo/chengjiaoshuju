import {parseQuickEntry} from '../parser.js';
import {normalizeTransaction,numberValue,AppError} from '../validation.js';
import {normalizeSpeechNumbers} from './numbers.js';
import {toSimplifiedChinese} from './chinese.js';
export function speechDraft(transcript,communities,{method='offline-whisper',warnings=[]}={}){
 if(typeof transcript!=='string'||!transcript.trim()||transcript.length>10000)throw new AppError('未识别到有效语音，请重录或输入文字',422);
 const rawTranscript=transcript;
 transcript=toSimplifiedChinese(transcript);
 const normalized=normalizeSpeechNumbers(transcript),parsed=parseQuickEntry(normalized.text,communities);
 parsed.data.original_text=transcript;parsed.original_text=transcript;parsed.data.source='语音录入';parsed.data.source_detail=`${method} · ${new Date().toISOString()}`;parsed.data.data_confidence='待核实';
 const conflicts=/不对|说错|更正|改为|改成|应该是|不是.*是/.test(normalized.text);
 if(conflicts){delete parsed.data.transaction_price;delete parsed.data.area_sqm;parsed.warnings.unshift('检测到口述更正，请根据完整转写手动填写最终面积和成交价');}
 // Detect competing evidence; field extraction itself remains in the shared parser.
 const ambiguous=[];
 for(const [key,pattern,kind,label]of [
  ['area_sqm',/([+-]?\d[\d.,]*)\s*(?:平方米|平米|平|m2)/gi,'area','面积'],
  ['transaction_price',/成交(?:总价|价格|价)?[：:\s]*([+-]?\d[\d.,]*\s*(?:万元|万|元|w))|([+-]?\d[\d.,]*\s*(?:万元|万|元|w))[ \t]*(?:成交|售出)/gi,'money','成交价'],
  ['listing_price',/(?<!最后)挂牌(?:价)?[：:\s]*([+-]?\d[\d.,]*\s*(?:万元|万|元|w))/gi,'money','挂牌价']
 ]){
  const values=[...normalized.text.matchAll(pattern)].map(m=>{try{return numberValue(m[1]||m[2],kind);}catch{return null;}}).filter(v=>v!==null);
  if(new Set(values).size>1){delete parsed.data[key];ambiguous.push(key);parsed.warnings.push(`口述中出现多个不同${label}，请手动填写最终值`);}
 }
 const validation=normalizeTransaction(parsed.data),data={...validation.data};
 for(const [key,value]of Object.entries(parsed.data))if(value!=null&&data[key]===undefined)data[key]=value;
 let unit=null;const match=normalized.text.match(/(?:成交单价|单价)[：:\s]*(\d[\d,.]*)/);if(match)try{unit=numberValue(match[1]);}catch{}
 const calculated=data.area_sqm>0&&data.transaction_price>0?data.transaction_price*10000/data.area_sqm:null;
 if(unit!==null&&calculated!==null&&Math.abs(unit-calculated)>Math.max(100,calculated*.01))parsed.warnings.push('口述单价与系统计算结果不一致，请核对面积和成交价');
 return {...parsed,data,errors:[...parsed.errors,...validation.errors],warnings:[...new Set([...warnings,...normalized.warnings,...parsed.warnings,...validation.warnings,'语音数字容易混淆，请逐项核对；未说出的字段保持未知。'])],voice_recognition:{method,transcript,raw_transcript:rawTranscript,output_script:'简体中文',normalized_text:normalized.text,requires_confirmation:true,correction_detected:conflicts,ambiguous_fields:ambiguous,recognized_unit_price:unit,calculated_unit_price:calculated,audio_retained:false},requires_confirmation:true};
}
