CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL) STRICT;
INSERT INTO schema_migrations VALUES(1, strftime('%Y-%m-%dT%H:%M:%fZ','now'));
CREATE TABLE communities (
 id INTEGER PRIMARY KEY, community_name TEXT NOT NULL, district TEXT, subdistrict TEXT,
 address TEXT, developer TEXT, build_year_start INTEGER, build_year_end INTEGER,
 phase TEXT, building_count INTEGER, household_count INTEGER, property_company TEXT,
 property_fee REAL, parking_info TEXT, notes TEXT, version INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
) STRICT;
CREATE TABLE community_names (
 name TEXT PRIMARY KEY, community_id INTEGER NOT NULL REFERENCES communities(id), is_alias INTEGER NOT NULL DEFAULT 0
) STRICT;
CREATE TABLE import_batches (
 id TEXT PRIMARY KEY, filename TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'preview',
 mapping TEXT NOT NULL, result TEXT, created_at TEXT NOT NULL, committed_at TEXT
) STRICT;
CREATE TABLE sources (
 id INTEGER PRIMARY KEY, source_type TEXT, source_detail TEXT, original_text TEXT,
 import_batch_id TEXT REFERENCES import_batches(id), created_at TEXT NOT NULL
) STRICT;
CREATE TABLE transactions (
 id INTEGER PRIMARY KEY, community_id INTEGER NOT NULL REFERENCES communities(id),
 community_name_snapshot TEXT NOT NULL, building_no TEXT, unit_no TEXT, room_no TEXT,
 transaction_date TEXT, listing_date TEXT,
 listing_price_fen INTEGER CHECK(listing_price_fen>0), final_listing_price_fen INTEGER CHECK(final_listing_price_fen>0),
 transaction_price_fen INTEGER CHECK(transaction_price_fen>0),
 area_sqm REAL CHECK(area_sqm>0 AND area_sqm<=3000),
 bedrooms INTEGER CHECK(bedrooms>=0 AND bedrooms<=20), living_rooms INTEGER CHECK(living_rooms>=0 AND living_rooms<=20),
 bathrooms INTEGER CHECK(bathrooms>=0 AND bathrooms<=20), floor_text TEXT,
 floor_number INTEGER CHECK(floor_number BETWEEN -10 AND 200), total_floors INTEGER CHECK(total_floors BETWEEN 1 AND 200),
 floor_category TEXT CHECK(floor_category IN ('低楼层','中楼层','高楼层') OR floor_category IS NULL), orientation TEXT,
 elevator INTEGER CHECK(elevator IN (0,1) OR elevator IS NULL), building_year INTEGER, layout_type TEXT, decoration TEXT,
 cycle_days_reported INTEGER CHECK(cycle_days_reported>=0), data_confidence TEXT CHECK(data_confidence IN ('已核实','待核实') OR data_confidence IS NULL),
 notes TEXT, source_id INTEGER NOT NULL REFERENCES sources(id),
 version INTEGER NOT NULL DEFAULT 1, deleted_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 CHECK(listing_date IS NULL OR transaction_date IS NULL OR listing_date<=transaction_date),
 CHECK(floor_number IS NULL OR total_floors IS NULL OR floor_number<=total_floors)
) STRICT;
CREATE INDEX idx_tx_community_date ON transactions(community_id, transaction_date) WHERE deleted_at IS NULL;
CREATE INDEX idx_tx_date ON transactions(transaction_date) WHERE deleted_at IS NULL;
CREATE INDEX idx_tx_area_price ON transactions(area_sqm,transaction_price_fen) WHERE deleted_at IS NULL;
CREATE INDEX idx_tx_updated ON transactions(updated_at DESC);
CREATE INDEX idx_tx_duplicate ON transactions(community_id,area_sqm,transaction_price_fen,transaction_date);
CREATE TABLE audit_logs (
 id INTEGER PRIMARY KEY, record_type TEXT NOT NULL, record_id INTEGER NOT NULL,
 field_changed TEXT NOT NULL, old_value TEXT, new_value TEXT, changed_at TEXT NOT NULL, change_reason TEXT NOT NULL
) STRICT;
CREATE INDEX idx_audit_record ON audit_logs(record_type,record_id,id DESC);
CREATE TABLE import_rows (
 batch_id TEXT NOT NULL REFERENCES import_batches(id), row_number INTEGER NOT NULL,
 raw_json TEXT NOT NULL, data_json TEXT NOT NULL, errors_json TEXT NOT NULL, warnings_json TEXT NOT NULL,
 PRIMARY KEY(batch_id,row_number)
) STRICT;
CREATE VIEW transaction_view AS SELECT t.*,
 c.community_name, s.source_type AS source, s.source_detail, s.original_text, s.import_batch_id,
 t.listing_price_fen/1000000.0 AS listing_price,
 t.final_listing_price_fen/1000000.0 AS final_listing_price,
 t.transaction_price_fen/1000000.0 AS transaction_price,
 CASE WHEN t.area_sqm IS NOT NULL THEN t.transaction_price_fen/100.0/t.area_sqm END AS price_per_sqm,
 (t.listing_price_fen-t.transaction_price_fen)/1000000.0 AS price_reduction_amount,
 (t.listing_price_fen-t.transaction_price_fen)*1.0/NULLIF(t.listing_price_fen,0) AS price_reduction_rate,
 CASE WHEN t.transaction_date IS NOT NULL AND t.listing_date IS NOT NULL
 THEN CAST(julianday(t.transaction_date)-julianday(t.listing_date) AS INTEGER) ELSE t.cycle_days_reported END AS transaction_cycle_days,
 CASE WHEN t.data_confidence='待核实' THEN '待核实'
 WHEN t.transaction_date IS NOT NULL AND t.area_sqm IS NOT NULL AND t.transaction_price_fen IS NOT NULL
 AND t.bedrooms IS NOT NULL AND t.floor_category IS NOT NULL AND t.orientation IS NOT NULL AND t.listing_price_fen IS NOT NULL THEN '完整'
 WHEN t.transaction_date IS NOT NULL AND t.area_sqm IS NOT NULL AND t.transaction_price_fen IS NOT NULL THEN '基本完整'
 ELSE '缺失较多' END AS quality_status
 FROM transactions t JOIN communities c ON c.id=t.community_id JOIN sources s ON s.id=t.source_id;
