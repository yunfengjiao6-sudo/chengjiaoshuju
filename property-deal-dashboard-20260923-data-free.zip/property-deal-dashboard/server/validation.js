import { floorFromRoom } from '../public/property-address.js';
export class AppError extends Error {
 constructor(message,status=400,details={}) { super(message); this.status=status; this.details=details; }
}
export const today = () => new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export const empty = v => v===null || v===undefined || (typeof v==='string' && ['','未知','不详','未提供','—','-','NULL','null'].includes(v.trim()));
export const textValue = v => empty(v)?null:String(v).trim();
export function numberValue(value,kind='number') {
 if(empty(value)) return null;
 if(!['string','number'].includes(typeof value))throw new AppError('请填写数字或带单位的文本');
 let str=String(value).trim().normalize('NFKC').replace(/\s/g,'');
 const hasGrouping=str.includes(',');
 if(hasGrouping&&!/^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?(?:万元|万|w|元|平方米|平米|平|m2)?$/i.test(str))throw new AppError('千位分隔格式错误，请使用如 6,890,000 的格式');
 str=str.replaceAll(',','');
 let factor=1;
 if(kind==='money') {
  if(/万元$|万$|w$/i.test(str)) str=str.replace(/万元$|万$|w$/i,'');
  else if(/元$/.test(str)) {str=str.replace(/元$/,'');factor=1/10000;}
  else if(typeof value==='string' && (hasGrouping || Number(str)>=100000)) factor=1/10000;
 } else if(kind==='area') str=str.replace(/平方米$|平米$|平$|m2$|㎡$/i,'');
 if(!/^[+-]?\d+(?:\.\d+)?$/.test(str) || !Number.isFinite(Number(str))) throw new AppError(`无法识别数值：${value}`);
 return Number(str)*factor;
}
export function dateValue(value) {
 if(empty(value)) return null;
 if(value instanceof Date) value=value.toISOString().slice(0,10);
 const match=String(value).trim().match(/^(\d{4})[-/.年](\d{1,2})[-/.月](\d{1,2})日?$/);
 if(!match) throw new AppError(`日期需含完整年月日：${value}`);
 const [,year,month,day]=match;
 const date=`${year}-${month.padStart(2,'0')}-${day.padStart(2,'0')}`;
 const parsed=new Date(date+'T00:00:00Z');
 if(Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0,10)!==date || +year<1900) throw new AppError(`无效日期：${value}`);
 return date;
}
export function parseTransactionCycleDays(value) {
 if(empty(value)||typeof value==='string'&&value.trim().toUpperCase()==='N/A')return null;
 const normalized=typeof value==='string'?value.trim().normalize('NFKC').replace(/\s/g,'').replace(/天$/,''):value;
 const days=numberValue(normalized);
 if(days===null||!Number.isInteger(days)||days<0||days>36500)throw new AppError('需为 0–36500 的合理整数');
 return days;
}
export const MONEY_FIELDS=['listing_price','final_listing_price','transaction_price'];
export const TEXT_FIELDS=['building_no','unit_no','room_no','floor_text','orientation','layout_type','decoration','notes','source','source_detail','original_text','data_confidence'];
export const INT_FIELDS=['bedrooms','living_rooms','bathrooms','floor_number','total_floors','building_year','cycle_days_reported'];
export const TX_FIELDS=['community_id','transaction_date','listing_date','area_sqm',...MONEY_FIELDS,...TEXT_FIELDS,...INT_FIELDS,'floor_category','elevator'];
const FIELD_LABELS={community_id:'小区',transaction_date:'成交日期',listing_date:'挂牌日期',area_sqm:'面积',listing_price:'挂牌价',final_listing_price:'最后挂牌价',transaction_price:'成交价',bedrooms:'房数',living_rooms:'厅数',bathrooms:'卫数',floor_number:'所在楼层',total_floors:'总楼层',building_year:'建成年份',cycle_days_reported:'周期(天)',source:'来源',source_detail:'来源详情',original_text:'原始输入',notes:'备注',building_no:'楼栋',unit_no:'单元',room_no:'室号',orientation:'朝向',floor_text:'楼层原文',decoration:'装修',layout_type:'户型',data_confidence:'核实状态'};
export function normalizeTransaction(input) {
 const data={},errors=[],warnings=[];
 const attempt=(key,fn) => {try {data[key]=fn();}catch(e){errors.push(`${FIELD_LABELS[key]||key}：${e.message}`);}};
 attempt('community_id',()=>numberValue(input.community_id));
 if(!Number.isInteger(data.community_id)||data.community_id<1) errors.push('请选择已建立的小区');
 for(const key of MONEY_FIELDS) attempt(key,()=>{
  const v=numberValue(input[key],'money');
  if(v!==null && (v<=0 || v>1000000 || Math.abs(v*1e6-Math.round(v*1e6))>0.0001)) throw new AppError('金额必须大于 0、不超过 100 万万元，精确到分');
  return v;
 });
 attempt('area_sqm',()=>{const n=numberValue(input.area_sqm,'area');if(n!==null&&(n<=0||n>3000))throw new AppError('面积须大于 0 且不超过 3000㎡');return n;});
 for(const key of ['transaction_date','listing_date']) attempt(key,()=>{const v=dateValue(input[key]);if(v&&v>today())throw new AppError('日期不能晚于今天');return v;});
 for(const key of TEXT_FIELDS) attempt(key,()=>{const v=textValue(input[key]);if(v&&v.length>(key==='original_text'?30000:5000))throw new AppError('内容过长');return v;});
 for(const key of INT_FIELDS) attempt(key,()=>{
  const n=key==='cycle_days_reported'?parseTransactionCycleDays(input[key]):numberValue(input[key]);const min=key==='floor_number'?-10:key==='building_year'?1800:0;
  const max=key==='building_year'?+today().slice(0,4):key==='cycle_days_reported'?36500:key.includes('floor')?200:20;
  if(n!==null&&(!Number.isInteger(n)||n<min||n>max||(key==='total_floors'&&n===0)))throw new AppError(`需为 ${min}–${max} 的合理整数`);
  return n;
 });
 // User-authorized room convention: 302 -> 3, 1302 -> 13. Explicit floors win.
 if(data.floor_number===null&&!data.floor_text)data.floor_number=floorFromRoom(data.room_no);
 data.floor_category=textValue(input.floor_category);
 const floorSource=data.floor_text||data.floor_category||'';
 const floorMatch=floorSource.match(/(低|中|高)(?:楼层|区|层)/);
 if(floorMatch) data.floor_category=`${floorMatch[1]}楼层`;
 if(data.floor_number!==null && data.total_floors) data.floor_category=data.floor_number/data.total_floors<=1/3?'低楼层':data.floor_number/data.total_floors<=2/3?'中楼层':'高楼层';
 if(data.floor_category&&!['低楼层','中楼层','高楼层'].includes(data.floor_category))errors.push('楼层分类只能是低楼层、中楼层或高楼层');
 if(data.floor_number!==null&&data.total_floors!==null&&data.floor_number>data.total_floors) errors.push('所在楼层不能高于总楼层');
 if(data.orientation) data.orientation=data.orientation.replace(/通透$|通$/,'').replace(/\s/g,'');
 if(empty(input.elevator)) data.elevator=null;
 else if([1,'1',true,'有','是'].includes(input.elevator))data.elevator=1;
 else if([0,'0',false,'无','否'].includes(input.elevator))data.elevator=0;
 else errors.push('电梯应为有、无或未知');
 if(data.data_confidence&&!['已核实','待核实'].includes(data.data_confidence))errors.push('核实状态无效');
 if(data.listing_date&&data.transaction_date&&data.listing_date>data.transaction_date)errors.push('挂牌日期不能晚于成交日期');
 if(data.listing_date&&data.transaction_date&&data.cycle_days_reported!==null) {
  const derived=Math.round((Date.parse(data.transaction_date)-Date.parse(data.listing_date))/86400000);
  if(derived!==data.cycle_days_reported)warnings.push(`填报周期 ${data.cycle_days_reported} 天与日期计算 ${derived} 天不同；统计采用日期计算值`);
 }
 if(data.transaction_price&&data.area_sqm){const unit=data.transaction_price*10000/data.area_sqm;if(unit<1000||unit>500000)warnings.push(`成交单价 ${Math.round(unit).toLocaleString()} 元/㎡异常，请核实`);}
 if(data.listing_price&&data.transaction_price>data.listing_price)warnings.push('成交价高于初始挂牌价，议价率为负，请核实');
 return {data,errors,warnings};
}
export function assertValid(result,confirmed=false) {
 if(result.errors.length) throw new AppError('数据校验未通过',422,{errors:result.errors,warnings:result.warnings});
 if(result.warnings.length&&confirmed!==true) throw new AppError('请确认异常数据后再保存',422,{warnings:result.warnings,confirmation_required:true});
 return result.data;
}
