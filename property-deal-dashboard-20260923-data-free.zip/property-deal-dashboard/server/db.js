import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

export const now = () => new Date().toISOString();
export function openDatabase(filename) {
 if (filename !== ':memory:') mkdirSync(dirname(resolve(filename)), {recursive:true});
 const db = new DatabaseSync(filename, {timeout:5000});
 db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;');
 const exists = db.prepare("SELECT name FROM sqlite_master WHERE name='schema_migrations'").get();
 if (!exists) atomic(db, () => db.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8')));
 const version = db.prepare('SELECT MAX(version) AS version FROM schema_migrations').get().version;
 if(version !== 1) { db.close(); throw new Error(`数据库版本 ${version} 不兼容，请使用匹配的软件版本`); }
 return db;
}
export function atomic(db, fn) {
 if(db.isTransaction) return fn();
 db.exec('BEGIN IMMEDIATE');
 try { const result=fn(); db.exec('COMMIT'); return result; }
 catch(error) { db.exec('ROLLBACK'); throw error; }
}
export function audit(db,type,id,field,oldValue,newValue,reason) {
 db.prepare('INSERT INTO audit_logs(record_type,record_id,field_changed,old_value,new_value,changed_at,change_reason) VALUES(?,?,?,?,?,?,?)')
 .run(type,id,field,oldValue==null?null:JSON.stringify(oldValue),newValue==null?null:JSON.stringify(newValue),now(),reason);
}
