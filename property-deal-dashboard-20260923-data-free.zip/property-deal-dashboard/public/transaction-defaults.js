export const DEFAULT_ORIENTATION='南';
// A default for new drafts only. Explicit corrections (including clearing) win.
export function withTransactionDefaults(input={}){
 return {...input,orientation:input.orientation===undefined?DEFAULT_ORIENTATION:input.orientation};
}
