import { $,api,session,esc,toast,reportError,formValues } from './ui.js';
import { renderDashboard,renderCommunities,setDashboardFilters,setRanking } from './dashboard.js';
import { renderTransactions,setSearch,tableAction,tableSubmit,tableChange } from './transactions.js';
import { configureForms,formsAction,formsSubmit,updateDerived } from './forms.js';
import { renderImport,importAction,importChange } from './imports.js';
import { renderManagement,renderSettings,managementAction } from './management.js';

let rendering=false,needsRender=false;
export async function render(){
 if(rendering){needsRender=true;return;}rendering=true;
 const route=location.hash.slice(1)||'overview';const [page,id]=route.split('/');
 const titles={overview:'数据总览',transactions:'成交记录',communities:'小区数据库',community:'小区详情',trends:'趋势分析',import:'数据导入',manage:'数据管理',settings:'系统设置'};
 $('#page-name').textContent=titles[page]||'数据总览';document.title=`${titles[page]||'数据总览'} · FLIN 楼盘成交数据库`;
 document.querySelectorAll('[data-nav]').forEach(el=>el.classList.toggle('active',el.dataset.nav===(page==='community'?'communities':page)));
 try{
  if(page==='transactions')await renderTransactions();
  else if(page==='communities')await renderCommunities();
  else if(page==='community')await renderDashboard(false,id);
  else if(page==='trends')await renderDashboard(true);
  else if(page==='import')renderImport();
  else if(page==='manage')await renderManagement();
  else if(page==='settings')await renderSettings();
  else await renderDashboard();
 }catch(e){$('#main').innerHTML=`<div class="notice error">${esc(e.message)}</div><button data-action="reload">重新加载</button>`;}
 finally{rendering=false;if(needsRender){needsRender=false;await render();}}
}
configureForms(render);
document.addEventListener('click',async event=>{
 const button=event.target.closest('[data-action]');if(!button||button.disabled)return;
 event.preventDefault();const action=button.dataset.action;button.disabled=true;
 try{if(action==='reload'){await render();return;}if(await formsAction(action,button))return;if(await tableAction(action,button))return;if(await importAction(action,button))return;await managementAction(action,button);}
 catch(error){reportError(error,$('#form-errors')||$('#import-errors'));}
 finally{button.disabled=false;}
});
document.addEventListener('submit',async event=>{
 event.preventDefault();const form=event.target;const submit=form.querySelector('[type=submit],button:not([type])');if(submit?.disabled)return;if(submit)submit.disabled=true;
 try{
  if(form.id==='global-search'){setSearch(new FormData(form).get('q'));if(location.hash==='#transactions')await render();else location.hash='transactions';return;}
  if(form.id==='dashboard-filter'){setDashboardFilters(formValues(form));await render();return;}
  if(await formsSubmit(form))return;await tableSubmit(form);
 }catch(e){reportError(e,$('#form-errors'));}finally{if(submit)submit.disabled=false;}
});
document.addEventListener('change',async event=>{try{await tableChange(event.target);await importChange(event.target);if(event.target.id==='ranking-key'){setRanking(event.target.value);await render();}}catch(e){reportError(e,$('#import-errors'));}});
document.addEventListener('input',event=>{if(event.target.closest('#transaction-form'))updateDerived();});
window.addEventListener('hashchange',()=>{render();window.scrollTo(0,0);});
try{const info=await session();$('#demo-banner').hidden=!info.demo;await render();}catch(e){$('#main').innerHTML=`<div class="notice error">无法连接本地服务：${esc(e.message)}。请运行“启动.cmd”后刷新。</div>`;}
