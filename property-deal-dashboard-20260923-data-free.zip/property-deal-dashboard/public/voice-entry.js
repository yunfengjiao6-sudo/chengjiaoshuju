import {$,api,toast} from './ui.js';
import {beginCapture,decodeAudioFile,audioBase64} from './audio-capture.js';
let applyResult,capture=null,generation=0,processing=false,recorded=null;
export function configureVoice(apply){applyResult=apply;$('#modal').addEventListener('close',()=>{generation++;capture?.cancel();capture=null;recorded=null;processing=false;});}
export function voiceInputHtml(){return `<section class="voice-area"><strong>语音录入成交</strong><p>普通话录入 · 简体中文输出 → 核对文字 → 整理字段。数字请逐项核对，确认后才会入库。</p><div class="actions"><button type="button" id="voice-start">🎤 开始录音</button><button type="button" id="voice-stop" hidden>结束并识别</button><button type="button" id="voice-cancel" hidden>取消录音</button><button type="button" id="voice-retry" hidden>重试识别</button><label class="button">选择音频<input type="file" id="voice-file" accept="audio/*,.wav,.mp3,.m4a" hidden></label></div><p id="voice-status" role="status" aria-live="polite">最长60秒 · 本机离线识别 · 不保存录音</p><label class="field">识别文字（简体中文，可修改）<textarea id="voice-text" placeholder="识别文字将在这里出现；也可输入或粘贴已有转写"></textarea></label><button type="button" id="voice-parse">整理为成交草稿</button></section>`;}
function controls(recording,busy=false){processing=busy;for(const id of ['voice-start','voice-file','voice-parse'])if($('#'+id))$('#'+id).disabled=recording||busy;if($('#voice-start'))$('#voice-start').hidden=recording;for(const id of ['voice-stop','voice-cancel'])if($('#'+id))$('#'+id).hidden=!recording;}
async function recognize(buffer,ticket){
 recorded=buffer;controls(false,true);$('#voice-status').textContent='正在识别普通话，请稍候……';$('#voice-retry').hidden=true;
 try{const result=await api('/recognition/voice',{audio:audioBase64(buffer)});if(ticket!==generation||!$('#voice-text'))return;$('#voice-text').value=result.voice_recognition.transcript;$('#voice-status').textContent='转写完成，请核对数字，再整理为成交草稿';recorded=null;}
 catch(e){if(ticket===generation&&$('#voice-status')){$('#voice-status').textContent=e.message;$('#voice-retry').hidden=false;}}
 finally{if(ticket===generation)controls(false,false);}
}
export function bindVoice(parsed){
 if(!$('#voice-start'))return;capture?.cancel();capture=null;recorded=null;processing=false;generation++;const ticket=generation;
 if(parsed?.voice_recognition)$('#voice-text').value=parsed.voice_recognition.transcript;
 $('#voice-start').onclick=async()=>{if(capture||processing)return;controls(false,true);$('#voice-status').textContent='正在打开麦克风……';try{const active=await beginCapture(()=>$('#voice-stop')?.click());if(ticket!==generation){await active.cancel();return;}capture=active;controls(true);$('#voice-status').textContent='正在听……说完请点“结束并识别”';}catch(e){if(ticket===generation){controls(false);$('#voice-status').textContent=e.message;}}};
 $('#voice-stop').onclick=async()=>{const active=capture;capture=null;if(!active)return;controls(false,true);try{const wav=await active.stop();if(ticket===generation)await recognize(wav,ticket);}catch(e){if(ticket===generation){controls(false);$('#voice-status').textContent=e.message;}}};
 $('#voice-cancel').onclick=async()=>{await capture?.cancel();capture=null;controls(false);$('#voice-status').textContent='已取消录音，没有保存成交或录音';};
 $('#voice-file').onchange=async e=>{const file=e.target.files[0];e.target.value='';if(!file||processing||capture)return;controls(false,true);try{const wav=await decodeAudioFile(file);if(ticket===generation)await recognize(wav,ticket);}catch(error){if(ticket===generation){controls(false);$('#voice-status').textContent=error.message;}}};
 $('#voice-retry').onclick=()=>{if(recorded&&!processing)recognize(recorded,ticket);};
 $('#voice-parse').onclick=async()=>{if(processing||capture)return;controls(false,true);try{const result=await api('/parse/voice',{text:$('#voice-text').value});if(ticket!==generation)return;await applyResult(result);}catch(e){toast(e.message,true);}finally{if(ticket===generation)controls(false);}};
}
