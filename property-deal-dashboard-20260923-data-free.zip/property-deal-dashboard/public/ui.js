export const $=(s,root=document)=>root.querySelector(s);
export const $$=(s,root=document)=>[...root.querySelectorAll(s)];
export const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const fmt=(value,digits=0)=>value==null?'—':Number(value).toLocaleString('zh-CN',{maximumFractionDigits:digits,minimumFractionDigits:digits});
export const pct=value=>value==null?'—':fmt(value*100,1)+'%';
export const layout=r=>r.bedrooms==null?'—':`${r.bedrooms}房${r.living_rooms==null?'':r.living_rooms+'厅'}${r.bathrooms==null?'':r.bathrooms+'卫'}`;
export function toast(message,error=false){const el=$('#toast');el.textContent=message;el.className=`show ${error?'error':''}`;clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>el.className='',4500);}
let token='';
export async function api(path,body,method){
 let response;
 try{response=await fetch('/api'+path,{method:method||(body?'POST':'GET'),headers:{'Content-Type':'application/json','X-FLIN-Token':token},...(body?{body:JSON.stringify(body)}:{})});}
 catch{throw new Error('连接失败，请检查本地服务后重试。当前页面中的草稿仍保留。');}
 const data=await response.json();if(!response.ok){const error=new Error(data.error||'请求失败');Object.assign(error,data);error.status=response.status;throw error;}return data;
}
export async function session(){const info=await api('/session');token=info.token;return info;}
export function head(title,english,subtitle,actions=''){return `<section class="page-head"><div><div class="eyebrow">${english}</div><h1>${esc(title)}</h1><p class="subtitle">${esc(subtitle)}</p></div><div class="actions">${actions}</div></section>`;}
export const addButton='<button data-action="new-voice">🎤 语音录入</button><button data-action="new-screenshot">▣ 截图识别录入</button><button class="primary" data-action="new-transaction"><span>＋</span>录入成交</button>';
export function empty(title='暂无成交数据',description='添加第一笔成交，开始积累自己的市场判断。',action=''){return `<div class="empty"><span class="empty-symbol">▥</span><strong>${esc(title)}</strong><p>${esc(description)}</p>${action}</div>`;}
export function panel(title,subtitle,body,extra=''){return `<section class="panel"><div class="panel-header"><div><h2>${esc(title)}</h2><p>${esc(subtitle)}</p></div>${extra}</div>${body}</section>`;}
export function metric(label,value,unit,meta='',featured=false){return `<div class="metric ${featured?'featured':''}"><div class="metric-label">${esc(label)}<span class="metric-icon">${featured?'▧':'◦'}</span></div><div class="metric-value">${esc(value)}<small>${esc(unit)}</small></div><div class="metric-meta">${esc(meta)}</div></div>`;}
export function badge(value){const style=value==='待核实'||value==='缺失较多'?'warn':value==='完整'?'':'neutral';return `<span class="badge ${style}">${esc(value)}</span>`;}
export const option=(value,label,selected)=>`<option value="${esc(value)}" ${String(value)===String(selected)?'selected':''}>${esc(label)}</option>`;
export function communityOptions(communities,selected,allLabel='全部小区'){return option('',allLabel,selected)+communities.map(c=>option(c.id,c.community_name,selected)).join('');}
export function showModal(title,content){$('#modal-body').innerHTML=`<div class="modal-head"><h2>${esc(title)}</h2><button data-action="close-modal" aria-label="关闭">×</button></div><div class="modal-content">${content}</div>`;if(!$('#modal').open)$('#modal').showModal();}
export function closeModal(){$('#modal').close();}
export function field(key,label,value='',type='text',attrs=''){return `<label class="field">${esc(label)}<input name="${esc(key)}" type="${type}" value="${esc(value)}" ${attrs}></label>`;}
export function selectField(key,label,items,value='',blank='未知'){return `<label class="field">${esc(label)}<select name="${esc(key)}">${option('',blank,value)}${items.map(i=>option(Array.isArray(i)?i[0]:i,Array.isArray(i)?i[1]:i,value)).join('')}</select></label>`;}
export function formValues(form){return Object.fromEntries(new FormData(form));}
export function reportError(error,target){const message=[error.message,...(error.errors||[]),...(error.warnings||[]),...(error.conflicts?['冲突字段：'+error.conflicts.join('、')]:[])].join('\n');if(target){target.innerHTML=`<div class="notice error">${esc(message)}</div>`;target.scrollIntoView({block:'nearest'});}else toast(message,true);}
export function exportLinks(query={}){const p=new URLSearchParams(query);return `<a class="button small" href="/api/export?${p}&format=csv">导出 CSV</a><a class="button small" href="/api/export?${p}&format=xlsx">导出 Excel</a>`;}
