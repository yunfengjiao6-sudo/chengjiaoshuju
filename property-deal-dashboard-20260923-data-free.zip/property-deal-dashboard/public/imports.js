import { transactionHeaders,transactionCells } from './transactions.js';
import { $,esc,api,head,option,reportError,toast,fmt,exportLinks } from './ui.js';
let upload=null,inspection=null,preview=null,loadSequence=0,previewSequence=0;
export function renderImport(){
 $('#main').innerHTML=head('导入历史成交','DATA IMPORT','先核对，再入库。每一行都有清楚的处理结果。',`<a class="button" href="/api/export?template=1&format=csv">CSV 模板</a><a class="button" href="/api/export?template=1&format=xlsx">Excel 模板</a>`)+`
 <div class="steps"><span class="current"><b>1</b>选择文件</span><span><b>2</b>映射与预览</span><span><b>3</b>确认入库</span></div>
 <section class="panel"><div class="upload-zone"><span class="upload-icon">⇧</span><h2>选择 CSV 或 Excel 文件</h2><p class="subtitle">支持 UTF-8 / GB18030 CSV、.xlsx · 每批最多 5,000 行 · 文件不超过 10 MB</p><input type="file" id="import-file" accept=".csv,.xlsx" aria-label="选择导入文件"><p class="small-text muted">文件只在本机读取。先建立小区及别名；未知房屋资料可留空。</p></div><div id="import-errors"></div><div id="mapping-container"></div><div id="preview-container"></div></section>`;
 if(inspection)showMapping();if(preview)showPreview();
}
export async function inspectFile(file){
 if(!file)return;
 const sequence=++loadSequence;inspection=null;preview=null;
 $('#mapping-container').innerHTML='<div class="loading">正在读取新文件…</div>';
 $('#preview-container').innerHTML='';$('#import-errors').innerHTML='';
 try{
  if(file.size>10*1024*1024)throw new Error('文件不能超过 10 MB');
  const bytes=new Uint8Array(await file.arrayBuffer());let binary='';
  for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
  const nextUpload={filename:file.name,file:btoa(binary)};
  const result=await api('/import/inspect',nextUpload);
  if(sequence!==loadSequence)return;
  upload=nextUpload;inspection=result;showMapping();
 }catch(error){if(sequence===loadSequence)$('#mapping-container').innerHTML='';throw error;}
}
function showMapping(){
 $('#mapping-container').innerHTML=`<div class="section-label">第二步 · 核对列映射</div><p class="small-text muted">文件：${esc(upload.filename)} · ${inspection.row_count} 行。裸数字金额默认万元；带“元”或千位逗号的金额按元识别。请核对单位。成交单价默认万/㎡，带“元”按元/㎡识别；文件单价保留于来源详情，统计采用成交价÷面积。属性保留于备注。未提供朝向时按你的设置默认南，入库后可编辑。</p>${inspection.sheets.length>1?`<label class="field">选择工作表<select id="import-sheet">${inspection.sheets.map(s=>option(s,s,upload.sheet||inspection.sheets[0])).join('')}</select></label>`:''}<div class="mapping-grid">${inspection.headers.map((h,i)=>`<label>${esc(h)} →<select data-map-index="${i}">${option('','忽略此列',inspection.mapping[h])}${Object.entries(inspection.fields).map(([key,label])=>option(key,label,inspection.mapping[h])).join('')}</select></label>`).join('')}</div><details><summary>查看原始文件前 8 行</summary><div class="table-wrap"><table><thead><tr>${inspection.headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${inspection.preview.map(r=>`<tr>${inspection.headers.map(h=>`<td>${esc(r[h])}</td>`).join('')}</tr>`).join('')}</tbody></table></div></details><div class="actions" style="margin-top:20px"><button class="primary" data-action="preview-import">校验并预览导入</button></div>`;
}
function showPreview(){
 const counts=preview.counts;
 $('#preview-container').innerHTML=`<div class="section-label">第三步 · 逐行确认</div><div class="import-summary"><span><strong>${counts.new}</strong>可新增</span><span><strong>${counts.duplicate}</strong>疑似重复</span><span><strong>${counts.error}</strong>错误 / 空行</span></div><p class="small-text muted">错误和重复默认跳过。确认提交前请检查各行；异常值需单独勾选。合并仅补充目标记录的空字段，有冲突时整批回滚。</p><div class="actions"><button class="small" data-action="download-import-report">下载校验报告</button></div><div class="table-wrap data-overflow" style="margin-top:15px"><table><thead><tr><th>原始行</th>${transactionHeaders()}<th>文件成交单价<br>万/㎡</th><th>周期(天)</th><th>校验结果</th><th>处理方式</th></tr></thead><tbody>${preview.rows.map(r=>`<tr><td>${r.row_number}</td>${transactionCells({...r.data,community_name:r.community_name,price_per_sqm:r.calculated_price_per_sqm,price_reduction_rate:r.data.listing_price>0&&r.data.transaction_price!=null?(r.data.listing_price-r.data.transaction_price)/r.data.listing_price:null})}<td>${fmt(r.price_per_sqm==null?null:r.price_per_sqm/10000,2)}</td><td>${fmt(r.data.cycle_days_reported,0)}</td><td style="white-space:normal;min-width:200px"><span class="badge ${r.status==='error'?'danger':r.status==='duplicate'?'warn':''}">${r.status==='new'?'可新增':r.status==='error'?'错误':'疑似重复'}</span>${r.errors.map(e=>`<div>${esc(e)}</div>`).join('')}${r.duplicates.map(d=>`<div><button class="text" data-action="view-transaction" data-id="${d.id}">查看 #${d.id}</button> ${esc(d.duplicate_reasons.join('、'))}</div>`).join('')}${r.batch_duplicate?`<div>与本批第 ${r.batch_duplicate} 行疑似重复</div>`:''}${r.warnings.length?`<label class="check" style="white-space:normal"><input type="checkbox" data-warning-row="${r.row_number}">${esc(r.warnings.join('；'))}（确认）</label>`:''}</td><td><select data-row-action="${r.row_number}" aria-label="第${r.row_number}行处理方式">${option('skip','跳过',r.status!=='new'?'skip':'create')}${r.status!=='error'?`${option('create','新增（仍检查重复）',r.status==='new'?'create':'skip')}${option('force','确认独立成交，仍新增','skip')}${r.duplicates.map(d=>option('merge:'+d.id,'合并至 #'+d.id,'skip')).join('')}`:''}</select></td></tr>`).join('')}</tbody></table></div><label class="check" style="margin-top:18px"><input type="checkbox" id="confirm-import">已核对映射、金额单位及每行处理方式，确认本次入库</label><div id="commit-errors"></div><div class="actions" style="margin-top:18px"><button class="primary" data-action="commit-import">确认导入</button></div>`;
}
export async function importAction(action){
 if(action==='preview-import'){
  const mapping=Object.create(null);document.querySelectorAll('[data-map-index]').forEach(s=>mapping[inspection.headers[+s.dataset.mapIndex]]=s.value);
  const sequence=++previewSequence,fileSequence=loadSequence;preview=null;$('#preview-container').innerHTML='<div class="loading">正在校验…</div>';
  try{const result=await api('/import/preview',{...upload,mapping});if(sequence!==previewSequence||fileSequence!==loadSequence)return true;preview=result;$('#import-errors').innerHTML='';showPreview();$('#preview-container').scrollIntoView({behavior:'smooth'});}catch(e){if(sequence===previewSequence&&fileSequence===loadSequence){$('#preview-container').innerHTML='';reportError(e,$('#import-errors'));}}return true;
 }
 if(action==='commit-import'){
  if(!$('#confirm-import').checked){toast('请先确认本次导入',true);return true;}
  const decisions={};for(const row of preview.rows){const val=$(`[data-row-action="${row.row_number}"]`).value;const [action,id]=val.split(':');const target=row.duplicates.find(d=>d.id===+id);decisions[row.row_number]={action,target_id:target?.id,version:target?.version,confirm_warnings:$(`[data-warning-row="${row.row_number}"]`)?.checked||false};}
  try{const r=await api('/import/commit',{batch_id:preview.batch_id,decisions});$('#preview-container').innerHTML=`<div class="notice success">导入完成：新增 ${r.created} 条，合并 ${r.merged} 条，跳过 ${r.skipped} 条。\n批次 ${esc(r.batch_id)}</div><a class="button primary" href="#transactions">查看成交记录 →</a>`;preview=null;toast('历史数据已入库');}catch(e){reportError(e,$('#commit-errors'));}return true;
 }
 if(action==='download-import-report'){
  const blob=new Blob([JSON.stringify(preview,null,2)],{type:'application/json;charset=utf-8'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='flin-import-report.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return true;
 }
 return false;
}
export async function importChange(target){
 if(target.matches('[data-map-index]')){previewSequence++;preview=null;$('#preview-container').innerHTML='';}
 if(target.id==='import-file')await inspectFile(target.files[0]);
 if(target.id==='import-sheet'){
  upload.sheet=target.value;previewSequence++;preview=null;$('#preview-container').innerHTML='';
  $('#mapping-container').innerHTML='<div class="loading">正在切换工作表…</div>';
  try{inspection=await api('/import/inspect',upload);showMapping();}catch(error){$('#mapping-container').innerHTML='';throw error;}
 }
}
