// Shared browser/server rules. Room suffixes encode floor only when unambiguous.
const clean=value=>value==null?'':String(value).trim();
export function floorFromRoom(value){
 const text=clean(value).normalize('NFKC').replace(/\s/g,'');
 const match=text.match(/^(?:\d+号(?:楼)?)?(\d{3,5})(?:室)?$/);
 if(!match)return null;
 const floor=Number(match[1].slice(0,-2));
 return floor>=1&&floor<=200?floor:null;
}
export function formatAddress(row){
 const building=clean(row.building_no),room=clean(row.room_no);
 if(!building)return room||'—';
 if(!room)return /\d$/.test(building)?building+'号':building;
 const combined=room.match(/^(\d+)号(?:楼)?\d+(?:室)?$/);
 if(combined&&building.replace(/号楼$|号$|栋$/,'')===combined[1])return room;
 const prefix=/\d$/.test(building)?building+'号':building;
 return combined?`${prefix} / ${room}`:prefix+room;
}
export function formatFloor(row){
 if(row.floor_number!=null)return `${row.floor_number}楼`;
 if(clean(row.floor_text))return /^\d+$/.test(clean(row.floor_text))?`${clean(row.floor_text)}楼`:clean(row.floor_text);
 const inferred=floorFromRoom(row.room_no);
 return inferred!==null?`${inferred}楼`:row.floor_category||'—';
}
export function migrateVisibleColumns(keys){
 return [...new Set(keys.map(key=>['building_no','room_no'].includes(key)?'address':key==='floor_category'?'floor_number':key))];
}
