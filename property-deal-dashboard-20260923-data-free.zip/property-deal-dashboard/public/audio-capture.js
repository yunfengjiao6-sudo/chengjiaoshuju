export function wavFromSamples(input,sampleRate){
 if(!input.length||input.length/sampleRate>60)throw new Error('录音需为60秒以内');
 const length=Math.floor(input.length*16000/sampleRate),buffer=new ArrayBuffer(44+length*2),view=new DataView(buffer);
 const text=(p,s)=>{for(let i=0;i<s.length;i++)view.setUint8(p+i,s.charCodeAt(i));};
 text(0,'RIFF');view.setUint32(4,36+length*2,true);text(8,'WAVEfmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,16000,true);view.setUint32(28,32000,true);view.setUint16(32,2,true);view.setUint16(34,16,true);text(36,'data');view.setUint32(40,length*2,true);
 // Average all source samples in each destination interval (including fractional edges).
 const ratio=sampleRate/16000;
 for(let i=0;i<length;i++){const start=i*ratio,end=(i+1)*ratio;let sum=0;for(let j=Math.floor(start);j<Math.ceil(end);j++)sum+=(input[j]||0)*(Math.min(j+1,end)-Math.max(j,start));const value=Math.max(-1,Math.min(1,sum/ratio));view.setInt16(44+i*2,Math.round(value*(value<0?32768:32767)),true);}
 return buffer;
}
export function audioBase64(buffer){const bytes=new Uint8Array(buffer);let text='';for(let i=0;i<bytes.length;i+=8192)text+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(text);}
export async function decodeAudioFile(file){
 if(!file||file.size>10*1024*1024)throw new Error('音频文件过大，最大10MB且不超过60秒');
 const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)throw new Error('浏览器不能解码音频，请换用新版浏览器或文字录入');
 const context=new Audio();try{const audio=await context.decodeAudioData(await file.arrayBuffer());if(audio.duration>60)throw new Error('音频超过60秒，请先分段');const mono=new Float32Array(audio.length);for(let c=0;c<audio.numberOfChannels;c++){const channel=audio.getChannelData(c);for(let i=0;i<mono.length;i++)mono[i]+=channel[i]/audio.numberOfChannels;}return wavFromSamples(mono,audio.sampleRate);}catch(e){throw new Error(e.message.includes('60秒')?e.message:'音频损坏或浏览器不支持此格式，请改用WAV/MP3或文字录入');}finally{await context.close();}
}
export async function beginCapture(onLimit){
 const Audio=window.AudioContext||window.webkitAudioContext;
 if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia||!Audio)throw new Error('录音需要HTTPS和支持麦克风的浏览器；也可选择音频文件');
 const context=new Audio();let stream,node,source,timer,stopped=false,frames=[],length=0;
 const dispose=async()=>{clearTimeout(timer);stream?.getTracks().forEach(t=>t.stop());node?.disconnect();source?.disconnect();if(context.state!=='closed')await context.close();};
 try{
  // Resume while the user's tap is still the active gesture (important on Safari).
  await context.resume();if(!context.audioWorklet)throw new Error('当前浏览器不支持录音组件，请选择音频文件');
  stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true},video:false});
  await context.audioWorklet.addModule('/audio-worklet.js');node=new AudioWorkletNode(context,'flin-pcm-capture');source=context.createMediaStreamSource(stream);
  node.port.onmessage=event=>{if(stopped)return;const data=event.data;if(length+data.length<=context.sampleRate*60){frames.push(data);length+=data.length;}};
  const gain=context.createGain();gain.gain.value=0;source.connect(node).connect(gain).connect(context.destination);
  timer=setTimeout(onLimit,59000);
  return {async stop(){if(stopped)throw new Error('录音已结束');stopped=true;const rate=context.sampleRate;await dispose();const all=new Float32Array(length);let p=0;for(const f of frames){all.set(f,p);p+=f.length;}frames=[];return wavFromSamples(all,rate);},async cancel(){stopped=true;frames=[];await dispose();}};
 }catch(error){await dispose();if(error.name==='NotAllowedError')throw new Error('麦克风权限未开启，请在浏览器设置中允许，或选择音频文件');if(error.name==='NotFoundError')throw new Error('没有找到麦克风，请选择音频文件或输入文字');throw error;}
}
