import { formatAddress,formatFloor,migrateVisibleColumns } from './property-address.js';
import { $,esc,fmt,pct,layout,api,head,addButton,empty,badge,option,communityOptions,field,selectField,exportLinks,formValues } from './ui.js';

const columns={transaction_date:['成交日期',r=>esc(r.transaction_date||'未知')],community_name:['小区',r=>`<a class="link" href="#community/${r.community_id}">${esc(r.community_name)}</a>`],address:['地址',r=>esc(formatAddress(r))],area_sqm:['面积 ㎡',r=>fmt(r.area_sqm,2)],bedrooms:['户型',r=>esc(layout(r))],floor_number:['楼层',r=>esc(formatFloor(r))],orientation:['朝向',r=>esc(r.orientation||'—')],listing_price:['挂牌价 万',r=>fmt(r.listing_price,2)],transaction_price:['成交价 万',r=>`<strong>${fmt(r.transaction_price,2)}</strong>`],price_per_sqm:['成交单价 元/㎡',r=>fmt(r.price_per_sqm)],price_reduction_rate:['议价率',r=>pct(r.price_reduction_rate)],transaction_cycle_days:['周期(天)',r=>fmt(r.transaction_cycle_days)],source:['来源',r=>esc(r.source||'—')],quality_status:['数据质量',r=>badge(r.quality_status)],notes:['备注',r=>esc(r.notes||'—')]};
export const CORE_TRANSACTION_COLUMNS=['transaction_date','community_name','address','area_sqm','bedrooms','floor_number','orientation','listing_price','transaction_price','price_per_sqm','price_reduction_rate'];
export const transactionHeaders=(keys=CORE_TRANSACTION_COLUMNS)=>keys.map(k=>`<th>${columns[k][0]}</th>`).join('');
export const transactionCells=(row,keys=CORE_TRANSACTION_COLUMNS)=>keys.map(k=>`<td>${columns[k][1](row)}</td>`).join('');
const withCore=keys=>[...CORE_TRANSACTION_COLUMNS,...migrateVisibleColumns(keys).filter(k=>columns[k]&&!CORE_TRANSACTION_COLUMNS.includes(k))];
let visible;try{visible=JSON.parse(localStorage.getItem('flin-columns'));}catch{}
visible=withCore(Array.isArray(visible)?visible:[]);
export let filters={page:1,page_size:25};
export function setSearch(q){filters={page:1,page_size:25,q};}
export function transactionTable(rows,{compact=false,deleted=false}={}){
 const keys=visible,sortable=!compact&&!deleted;
 if(!rows.length)return empty(deleted?'回收站为空':'没有符合条件的成交','可调整筛选条件，或录入、导入新的成交记录。',deleted?'':addButton);
 return `<div class="table-wrap"><table data-transaction-table><thead><tr>${keys.map(k=>`<th>${!sortable?columns[k][0]:`<button data-action="sort-transactions" data-key="${k}">${columns[k][0]} ${filters.sort===k?(filters.order==='asc'?'↑':'↓'):''}</button>`}</th>`).join('')}<th>操作</th></tr></thead><tbody>${rows.map(r=>`<tr>${transactionCells(r,keys)}<td><div class="actions">${deleted?`<button class="text" data-action="restore-transaction" data-id="${r.id}" data-version="${r.version}">恢复</button>`:`<button class="text" data-action="view-transaction" data-id="${r.id}">查看</button>${compact?'':`<button class="text" data-action="edit-transaction" data-id="${r.id}">编辑</button><button class="text" data-action="copy-transaction" data-id="${r.id}">复制</button><button class="text" data-action="delete-transaction" data-id="${r.id}" data-version="${r.version}">删除</button>`}`}</div></td></tr>`).join('')}</tbody></table></div>`;
}
const range=(a,b,label,unit='')=>`<label class="field">${label}${unit}<span class="range"><input name="${a}" value="${esc(filters[a])}" type="number" min="0" step="any" placeholder="最低"><span>—</span><input name="${b}" value="${esc(filters[b])}" type="number" min="0" step="any" placeholder="最高"></span></label>`;
export async function renderTransactions(){
 const [result,communities]=await Promise.all([api('/transactions?'+new URLSearchParams(filters)),api('/communities')]);
 $('#main').innerHTML=head('成交记录','TRANSACTION LEDGER','每笔成交独立留存，信息可持续补充。',`<a class="button" href="#import">批量导入</a>${addButton}`)+`
 <section class="panel filters-panel"><form id="transaction-filters"><div class="filter-grid">
 ${field('q','关键词',filters.q??'','search','placeholder="小区 / 面积 / 成交价 / 楼栋"')}
 <label class="field">小区<select name="community_id">${communityOptions(communities,filters.community_id)}</select></label>
 ${field('date_from','成交日期起',filters.date_from??'','date')}${field('date_to','成交日期止',filters.date_to??'','date')}
 ${selectField('quality_status','数据质量',['完整','基本完整','缺失较多','待核实'],filters.quality_status,'不限')}
 </div><details><summary>更多筛选 · 面积 / 总价 / 单价 / 户型 / 朝向</summary><div class="filter-grid">${range('area_min','area_max','面积 / ㎡')}${range('price_min','price_max','总价 / 万')}${range('unit_min','unit_max','单价 / 元/㎡')}${selectField('bedrooms','房数',[[0,'开间'],[1,'一房'],[2,'两房'],[3,'三房'],[4,'四房'],[5,'五房']],filters.bedrooms,'不限')}${selectField('floor_category','楼层',['低楼层','中楼层','高楼层'],filters.floor_category,'不限')}${field('orientation','朝向',filters.orientation??'','text','placeholder="例如 南北"')}</div></details><div class="actions"><button type="button" data-action="reset-filters">重置</button><button class="primary">查询成交</button></div></form></section>
 <section class="panel table-panel"><div class="panel-header"><div><h2>全部成交 <span class="badge neutral">${fmt(result.total)} 套</span></h2><p>各页面固定显示相同的 11 项基础指标 · 金额万元 · 未知「—」</p></div><div class="actions">${exportLinks(filters)}<button class="small" data-action="toggle-columns">显示列</button></div></div>
 <div id="column-config" hidden style="padding:0 24px"><div class="checkbox-grid">${Object.entries(columns).map(([key,[label]])=>`<label class="check"><input type="checkbox" data-column="${key}" ${visible.includes(key)?'checked':''} ${CORE_TRANSACTION_COLUMNS.includes(key)?'disabled':''}>${label}</label>`).join('')}</div></div>
 ${transactionTable(result.rows)}<div class="table-foot"><span>共 ${fmt(result.total)} 条 · 第 ${result.page} / ${Math.max(1,Math.ceil(result.total/result.page_size))} 页</span><div class="pagination"><select id="page-size" aria-label="每页条数">${[25,50,100].map(v=>option(v,`${v} 条/页`,filters.page_size)).join('')}</select><button class="small" data-action="prev-page" ${result.page<=1?'disabled':''}>上一页</button><button class="small" data-action="next-page" ${result.page*result.page_size>=result.total?'disabled':''}>下一页</button></div></div></section>`;
}
export async function tableAction(action,button){
 if(action==='toggle-columns'){$('#column-config').hidden=!$('#column-config').hidden;return true;}
 if(action==='reset-filters'){filters={page:1,page_size:25};await renderTransactions();return true;}
 if(action==='prev-page'||action==='next-page'){filters.page=+filters.page+(action==='next-page'?1:-1);await renderTransactions();return true;}
 if(action==='sort-transactions'){filters.order=filters.sort===button.dataset.key&&filters.order!=='asc'?'asc':'desc';filters.sort=button.dataset.key;filters.page=1;await renderTransactions();return true;}
 return false;
}
export async function tableSubmit(form){if(form.id!=='transaction-filters')return false;filters={...formValues(form),page:1,page_size:filters.page_size};await renderTransactions();return true;}
export async function tableChange(target){if(target.id==='page-size'){filters.page_size=+target.value;filters.page=1;await renderTransactions();}if(target.dataset.column){const boxes=[...document.querySelectorAll('[data-column]:checked')];if(!boxes.length){target.checked=true;return;}visible=withCore(boxes.map(b=>b.dataset.column));localStorage.setItem('flin-columns',JSON.stringify(visible));await renderTransactions();$('#column-config').hidden=false;}}
