import { $,esc,fmt,pct,layout,api,showModal,closeModal,field,selectField,option,communityOptions,formValues,reportError,toast,badge } from './ui.js';
import {configureImageEntry,imageInputHtml,imagePreviewHtml,bindImageEntry} from './image-entry.js';
import { withTransactionDefaults } from './transaction-defaults.js';
import {configureVoice,voiceInputHtml,bindVoice} from './voice-entry.js';

let refresh=()=>{},current=null,pending=null,parsedBaseline={},lastParsedKeys=[],recognitionBlocked=false;
const moneyText=value=>value==null?'':typeof value==='number'&&value>=100000?`${value}万`:value;
export function configureForms(callback){refresh=callback;configureImageEntry(()=>transactionForm(),applyParsedResult);configureVoice(applyParsedResult);}
export async function transactionForm(record={},copy=false,parsed=null){
 const communities=await api('/communities');
 recognitionBlocked=!!parsed?.image_recognition?.blocked;
 current=copy?withTransactionDefaults({...record,id:null,version:null}):record.id?record:withTransactionDefaults(record);
 if(!parsed){parsedBaseline={...current};lastParsedKeys=[];}else lastParsedKeys=Object.keys(parsed.data);
 const d=current;
 showModal(d.id?'编辑成交 · #'+d.id:copy?'复制成交':'录入一笔成交',`
 <div class="quick-area"><label for="quick-text">快速录入成交 <span class="muted">/ 粘贴原始信息，自动整理</span></label><textarea id="quick-text" placeholder="虚构格式示例：示例小区，80平，2房1厅1卫，中楼层，南北，成交400万，成交日期2025-01-01，挂牌420万，挂牌周期30天。">${esc(parsed?.original_text||'')}</textarea><div class="actions"><small>本地解析 · 原文保留 · 保存前请核对</small><button class="small" data-action="parse-entry">识别并填入 ↓</button></div></div>
 ${imageInputHtml()}
 ${voiceInputHtml()}
 ${parsed?`<div class="notice">${esc(parsed.warnings.join('\n'))}</div>`:''}
 ${parsed?.errors?.length?`<div class="notice error">${esc(parsed.errors.join('\n'))}</div>`:''}
 ${parsed?.image_recognition?`<div class="recognition-layout">${imagePreviewHtml(parsed)}`:''}
 <form id="transaction-form">
 <div class="section-label">基本信息</div><div class="form-grid">
 <label class="field">小区 *<select name="community_id" required>${communityOptions(communities,d.community_id,'请选择小区')}</select></label>
 ${field('area_sqm','建筑面积 / ㎡',d.area_sqm??'','text','inputmode="decimal" placeholder="未知可留空"')}
 ${field('transaction_date','成交日期',d.transaction_date??'','date',parsed?.invalid_fields?.includes('transaction_date')?'required':'')}
 </div><p class="small-text muted">还没有这个小区？可先在「小区数据库」建立名称和别名，其他资料以后补充。</p>
 <div class="section-label">成交价格</div><div class="form-grid">${field('transaction_price','成交价 / 万元',moneyText(d.transaction_price),'text','inputmode="decimal" placeholder="虚构示例 400 或 400万"')}${field('listing_price','初始挂牌价 / 万元',moneyText(d.listing_price),'text','inputmode="decimal"')}${field('final_listing_price','最后挂牌价 / 万元',moneyText(d.final_listing_price),'text','inputmode="decimal"')}</div>
 <div id="derived-preview" class="derived-preview"></div>
 <details ${d.id||parsed?.image_recognition||parsed?.voice_recognition?'open':''}><summary>房屋情况 · 户型 / 楼层 / 朝向</summary><div class="form-grid">
 ${field('bedrooms','房',d.bedrooms??'','number','min="0" max="20"')}${field('living_rooms','厅',d.living_rooms??'','number','min="0" max="20"')}${field('bathrooms','卫',d.bathrooms??'','number','min="0" max="20"')}
 ${field('floor_text','楼层原文',d.floor_text??'','text','placeholder="例如 中楼层"')}${field('floor_number','所在楼层',d.floor_number??'','number','min="-10" max="200" placeholder="留空按室号识别，如1302→13楼"')}${field('total_floors','总楼层',d.total_floors??'','number','min="1" max="200"')}
 ${selectField('floor_category','楼层分类',['低楼层','中楼层','高楼层'],d.floor_category)}${field('orientation','朝向（默认南，可修改）',d.orientation??'','text','placeholder="例如 南北通透"')}${selectField('elevator','电梯',[[1,'有'],[0,'无']],d.elevator)}
 ${field('building_no','楼栋',d.building_no??'')}${field('unit_no','单元',d.unit_no??'')}${field('room_no','室号',d.room_no??'')}
 ${field('building_year','建成年份',d.building_year??'','number')}${field('layout_type','户型类型',d.layout_type??'')}${field('decoration','装修',d.decoration??'')}
 </div></details>
 <details ${d.id||parsed?.image_recognition||parsed?.voice_recognition?'open':''}><summary>成交情况 · 日期 / 周期 / 来源</summary><div class="form-grid">
 ${field('listing_date','挂牌日期',d.listing_date??'','date',parsed?.invalid_fields?.includes('listing_date')?'required':'')}${field('cycle_days_reported','填报成交周期 / 天',d.cycle_days_reported??'','number','min="0"')}${selectField('data_confidence','核实状态',['已核实','待核实'],d.data_confidence)}
 ${field('source','数据来源',d.source??(d.id?'':'人工录入'))}${field('source_detail','来源详情',d.source_detail??'')}
 </div><p class="small-text muted">已填写挂牌与成交日期时，统计周期采用两者之差；填报值单独保留。</p></details>
 <details><summary>补充信息 · 备注 / 原始输入</summary><div class="form-grid two"><label class="field full">备注<textarea name="notes">${esc(d.notes)}</textarea></label><label class="field full">原始输入<textarea name="original_text">${esc(d.original_text)}</textarea></label>${d.id?field('change_reason','修改原因','','text','placeholder="例如 补充楼栋与挂牌资料"'):''}</div></details>
 ${parsed||['截图识别','语音录入'].includes(d.source)?'<label class="check" style="margin-top:18px"><input name="parsed_confirmed" type="checkbox" required> 我已核对识别内容、推断日期和未知字段</label>':''}
 <div id="form-errors"></div><div id="duplicate-actions"></div>
 <div class="modal-actions"><button type="button" data-action="close-modal">取消</button><button class="primary" type="submit">${d.id?'保存修改':'确认并保存成交'}</button></div>
 </form>${parsed?.image_recognition?'</div>':''}`);
 $('#modal').classList.toggle('image-mode',!!parsed?.image_recognition);
 bindImageEntry(parsed);
 bindVoice(parsed);
 updateDerived();
}
function previewNumber(value,money=false){if(!value)return null;const raw=String(value).normalize('NFKC');let s=raw.replace(/[,\s]/g,'');let factor=1;if(money){if(/万元$|万$|w$/i.test(s))s=s.replace(/万元$|万$|w$/i,'');else if(/元$/.test(s)){s=s.slice(0,-1);factor=1/10000;}else if(raw.includes(',')||Number(s)>=100000)factor=1/10000;}else s=s.replace(/平方米$|平米$|平$|m2$/i,'');const n=Number(s);return Number.isFinite(n)?n*factor:null;}
async function applyParsedResult(result){
 const live=formValues($('#transaction-form'));
 if(!lastParsedKeys.length)parsedBaseline={...current,...live};
 const d={...current,...live};
 for(const key of lastParsedKeys){const rendered=['transaction_price','listing_price','final_listing_price'].includes(key)?moneyText(current[key]):current[key]??'';if(String(live[key]??'')===String(rendered))d[key]=parsedBaseline[key]??null;}
 Object.assign(d,result.data);
 // OCR may return NULL for an unseen field: keep the editable form default or correction.
 if(result.data.orientation==null)d.orientation=live.orientation;
 if(d.transaction_date){const m=d.transaction_date.match(/^(\d{4})[-/.年](\d{1,2})[-/.月](\d{1,2})日?$/);if(m)d.transaction_date=`${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;}
 await transactionForm(d,false,result);
}
export function updateDerived(){const f=$('#transaction-form');if(!f)return;const d=formValues(f),a=previewNumber(d.area_sqm),p=previewNumber(d.transaction_price,true),l=previewNumber(d.listing_price,true);$('#derived-preview').innerHTML=`<span>成交单价<strong>${a>0&&p>0?fmt(p*10000/a)+' 元/㎡':'—'}</strong></span><span>议价金额<strong>${l>0&&p>0?fmt(l-p,2)+' 万':'—'}</strong></span><span>议价率<strong>${l>0&&p>0?pct((l-p)/l):'—'}</strong></span><span class="muted">填写价格与面积后自动计算</span>`;}
async function submitTransaction(options={}){
 if(recognitionBlocked){toast('请裁剪为单套有效成交后重新识别',true);return;}
 const form=$('#transaction-form');if(!form.reportValidity())return;
 const input={...formValues(form),...(current.id?{version:current.version}:{}),options};pending=input;
 try{await api(current.id?`/transactions/${current.id}`:'/transactions',input,current.id?'PATCH':'POST');closeModal();toast('成交已保存，看板已更新');await refresh();}
 catch(error){
  reportError(error,$('#form-errors'));
  if(error.confirmation_required)$('#duplicate-actions').innerHTML='<label class="check"><input type="checkbox" id="confirm-warning"> 已核实以上异常值，仍要保存</label><button type="button" class="small" data-action="confirm-warning">确认异常并保存</button>';
  else if(error.duplicates){$('#duplicate-actions').innerHTML=`<div class="notice">疑似重复不会覆盖已有记录。你可以跳过、查看已有记录、合并空字段，或确认是另一笔成交后仍然新增。</div>${error.duplicates.map(r=>`<div class="duplicate-card"><strong>#${r.id} ${esc(r.community_name)}</strong> · ${esc(r.transaction_date||'日期未知')} · ${fmt(r.area_sqm,2)}㎡ · ${fmt(r.transaction_price,2)}万<br><span class="muted">${esc(r.duplicate_reasons.join('、'))}</span><div class="actions" style="margin-top:8px"><button type="button" class="small" data-action="view-duplicate" data-id="${r.id}">查看</button><button type="button" class="small" data-action="merge-duplicate" data-id="${r.id}" data-version="${r.version}">合并空字段</button></div><div id="duplicate-detail-${r.id}"></div></div>`).join('')}<div class="actions"><button type="button" data-action="close-modal">跳过</button><button type="button" data-action="force-transaction">${current.id?'确认修改为独立成交':'仍然新增独立成交'}</button></div>`;}
 }
}
export async function communityForm(id=null){
 const c=id?(await api('/communities')).find(c=>c.id===+id):{};
 showModal(id?'编辑小区':'建立小区',`<form id="community-form" data-id="${id||''}" data-version="${c.version||''}"><div class="section-label">先建立名称，资料可以慢慢补全</div><div class="form-grid two">${field('community_name','小区名称 *',c.community_name??'','text','required placeholder="例如 示例小区（虚构）"')}${field('alias_names','常用别名（逗号分隔）',c.alias_names?.join('，')??'')}${field('district','行政区',c.district??'','text','placeholder="例如 所在行政区"')}${field('subdistrict','板块 / 街道',c.subdistrict??'','text','placeholder="例如 所在板块"')}${field('address','地址',c.address??'')}${field('phase','分期',c.phase??'')}</div><details><summary>更多小区资料</summary><div class="form-grid two">${field('developer','开发商',c.developer??'')}${field('property_company','物业公司',c.property_company??'')}${field('build_year_start','建成年份起',c.build_year_start??'','number')}${field('build_year_end','建成年份止',c.build_year_end??'','number')}${field('building_count','楼栋数',c.building_count??'','number','min="0"')}${field('household_count','总户数',c.household_count??'','number','min="0"')}${field('property_fee','物业费 / 元/㎡/月',c.property_fee??'','number','min="0" step="0.01"')}${field('parking_info','停车信息',c.parking_info??'')}<label class="field full">备注<textarea name="notes">${esc(c.notes)}</textarea></label></div></details><div id="form-errors"></div><div class="modal-actions"><button type="button" data-action="close-modal">取消</button><button class="primary">保存小区</button></div></form>`);
}
export async function viewTransaction(id){
 const [r,history]=await Promise.all([api(`/transactions/${id}`),api(`/transactions/${id}/history`)]);
 const fields={community_name:'小区',community_name_snapshot:'录入时小区名',transaction_date:'成交日期',area_sqm:'面积 / ㎡',transaction_price:'成交价 / 万',listing_price:'挂牌价 / 万',final_listing_price:'最后挂牌价 / 万',price_per_sqm:'单价 / 元/㎡',building_no:'楼栋',unit_no:'单元',room_no:'室号',floor_text:'楼层原文',floor_number:'所在楼层',total_floors:'总楼层',floor_category:'楼层分类',orientation:'朝向',listing_date:'挂牌日期',transaction_cycle_days:'计算周期 / 天',cycle_days_reported:'填报周期 / 天',source:'来源',source_detail:'来源详情',decoration:'装修',building_year:'建成年份',layout_type:'户型类型',data_confidence:'核实状态'};
 showModal(`成交详情 · #${id}`,`<div class="actions" style="margin-top:20px">${badge(r.quality_status)}<span class="muted small-text">${esc(layout(r))} · 议价率 ${pct(r.price_reduction_rate)}</span></div><dl class="detail-grid">${Object.entries(fields).map(([key,label])=>`<div><dt>${label}</dt><dd>${esc(r[key]??'未知')}</dd></div>`).join('')}</dl><h3>备注</h3><p class="raw-text">${esc(r.notes||'未填写')}</p><h3>原始输入</h3><pre class="raw-text">${esc(r.original_text||'结构化录入，无粘贴原文；详见创建审计')}</pre><details><summary>修改记录 · ${history.length} 项</summary>${history.map(h=>`<div class="history-item"><strong>${esc(h.field_changed)}</strong> · ${esc(h.change_reason)}<small>${esc(h.changed_at)} / ${esc(h.old_value??'空')} → ${esc(h.new_value??'空')}</small></div>`).join('')}</details><div class="modal-actions"><button data-action="copy-transaction" data-id="${id}">复制</button><button class="danger" data-action="delete-transaction" data-id="${id}" data-version="${r.version}">移入回收站</button><button class="primary" data-action="edit-transaction" data-id="${id}">编辑成交</button></div>`);
}
export async function formsAction(action,button){
 const id=button.dataset.id;
 if(action==='close-modal'){closeModal();return true;}
 if(action==='new-transaction'||action==='new-screenshot'||action==='new-voice'){await transactionForm();if(action==='new-screenshot')$('#image-drop').focus();if(action==='new-voice')$('#voice-start').focus();return true;}
 if(action==='new-community'||action==='edit-community'){await communityForm(id);return true;}
 if(action==='edit-transaction'||action==='copy-transaction'){await transactionForm(await api(`/transactions/${id}`),action==='copy-transaction');return true;}
 if(action==='view-transaction'){await viewTransaction(id);return true;}
 if(action==='parse-entry'){
  const result=await api('/parse',{text:$('#quick-text').value});
  await applyParsedResult(result);return true;
 }
 if(action==='confirm-warning'){if(!$('#confirm-warning').checked){toast('请先勾选确认异常值',true);return true;}await submitTransaction({...pending.options,confirm_warnings:true});return true;}
 if(action==='force-transaction'){await submitTransaction({...pending.options,allow_duplicate:true});return true;}
 if(action==='view-duplicate'){const r=await api(`/transactions/${id}`);$(`#duplicate-detail-${id}`).innerHTML=`<pre class="raw-text">${esc(JSON.stringify(r,null,2))}</pre>`;return true;}
 if(action==='merge-duplicate'){
  try{await api(`/transactions/${id}/merge`,{...pending,version:+button.dataset.version});closeModal();toast('已合并空字段，原有信息已保留');await refresh();}catch(e){reportError(e,$('#form-errors'));}return true;
 }
 if(action==='delete-transaction'){
  showModal('将成交移入回收站',`<p style="margin-top:22px">成交 #${esc(id)} 将从看板和查询中移除，仍可在「数据管理 → 回收站」恢复。历史修改记录会保留。</p><div id="form-errors"></div><div class="modal-actions"><button data-action="close-modal">取消</button><button class="danger" data-action="confirm-delete" data-id="${id}" data-version="${button.dataset.version}">确认移入回收站</button></div>`);return true;
 }
 if(action==='confirm-delete'){await api(`/transactions/${id}`,{version:+button.dataset.version},'DELETE');closeModal();toast('已移入回收站');await refresh();return true;}
 if(action==='restore-transaction'){
  try{await api(`/transactions/${id}/restore`,{version:+button.dataset.version});toast('成交已恢复');await refresh();}
  catch(error){if(!error.duplicates)throw error;showModal('恢复前核对疑似重复',`<div class="notice">${esc(error.message)}</div>${error.duplicates.map(r=>`<p>#${r.id} ${esc(r.community_name)} · ${esc(r.transaction_date||'日期未知')} · ${fmt(r.area_sqm,2)}㎡ · ${fmt(r.transaction_price,2)}万</p>`).join('')}<div id="form-errors"></div><div class="modal-actions"><button data-action="close-modal">取消恢复</button><button data-action="confirm-restore" data-id="${id}" data-version="${button.dataset.version}">确认独立成交，仍然恢复</button></div>`);}
  return true;
 }
 if(action==='confirm-restore'){await api(`/transactions/${id}/restore`,{version:+button.dataset.version,options:{allow_duplicate:true}});closeModal();toast('成交已恢复');await refresh();return true;}
 return false;
}
export async function formsSubmit(form){
 if(form.id==='transaction-form'){await submitTransaction();return true;}
 if(form.id==='community-form'){
  const id=form.dataset.id;
  try{await api(id?`/communities/${id}`:'/communities',{...formValues(form),version:+form.dataset.version},id?'PATCH':'POST');closeModal();toast('小区已保存');await refresh();}catch(e){reportError(e,$('#form-errors'));}return true;
 }
 return false;
}
