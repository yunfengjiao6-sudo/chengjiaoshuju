import {$,esc,api,toast} from './ui.js';

let openForm,applyResult,generation=0,busy=false;
export function configureImageEntry(open,apply){
 openForm=open;applyResult=apply;
 document.addEventListener('paste',async event=>{
  const items=[...(event.clipboardData?.items||[])],item=items.find(i=>i.kind==='file'&&i.type.startsWith('image/'));
  if(!item||($('#modal').open&&!$('#transaction-form')))return;
  event.preventDefault();const file=item.getAsFile();if(!$('#transaction-form'))await openForm();recognizeFile(file);
 });
 $('#modal').addEventListener('close',()=>{generation++;busy=false;});
}
export function imageInputHtml(){return `<section id="image-drop" class="image-drop" tabindex="0" aria-label="截图识别录入，支持粘贴或拖放"><div><strong>截图识别录入</strong><span>Ctrl+V 粘贴截图 · 拖拽到这里</span></div><label class="button small">选择图片<input id="image-file" type="file" accept="image/png,image/jpeg,image/webp" hidden></label><p id="image-status" role="status" aria-live="polite">本机中文识别 · 图片不上传云端 · 单套房源 · 最大8MB</p></section>`;}
export function imagePreviewHtml(parsed){
 const info=parsed?.image_recognition;if(!info)return '';
 return `<aside class="image-evidence"><img src="${esc(parsed.preview_url)}" alt="待核对的成交截图"><p class="small-text">原图仅在当前页面暂存，不保存到数据库。</p><div class="notice ${info.blocked?'error':''}">${info.blocked?'请裁剪为单套有效成交后重试，当前识别结果不能保存。':'识别完成，请核对右侧字段。所有字段均为待确认，不代表OCR准确率。'}</div><details><summary>识别原文与来源</summary><pre class="raw-text">${esc(info.raw_text)}</pre><small>${esc(info.method)} · ${esc(info.timestamp)}</small></details>${!parsed.data.community_id?`<div class="image-community"><p>匹配不确定，请选择已有小区，或核对名称后创建：</p>${info.community_matches.map(c=>`<p>${esc(c.name)} · ${esc(c.match)}</p>`).join('')}<label>新小区名称<input id="image-new-community" placeholder="核对截图中的小区名称"></label><button type="button" id="image-create-community">创建新小区并选中</button><p id="image-community-error" role="status"></p></div>`:''}</aside>`;
}
function lockForm(locked){busy=locked;for(const el of document.querySelectorAll('#transaction-form input,#transaction-form select,#transaction-form textarea,#transaction-form button,#quick-text,[data-action="parse-entry"]'))el.disabled=locked;}
export function bindImageEntry(parsed){
 const drop=$('#image-drop');if(!drop)return;
 $('#image-file').onchange=event=>{const file=event.target.files[0];event.target.value='';if(file)recognizeFile(file);};
 drop.ondragover=event=>{event.preventDefault();drop.classList.add('dragging');};drop.ondragleave=()=>drop.classList.remove('dragging');
 drop.ondrop=event=>{event.preventDefault();drop.classList.remove('dragging');if(event.dataTransfer.files.length!==1){$('#image-status').textContent='每次识别一张截图，请分别操作';return;}recognizeFile(event.dataTransfer.files[0]);};
 if(parsed?.image_recognition){
  for(const input of document.querySelectorAll('#transaction-form [name]')){
   if(['parsed_confirmed','source','source_detail','original_text','notes','data_confidence'].includes(input.name))continue;
   const evidence=parsed.image_recognition.fields[input.name];const label=input.closest('label');if(!label)continue;
   const tag=document.createElement('small');tag.className='ocr-confidence '+(evidence?.status==='LOW'?'low':'');tag.textContent=evidence?(evidence.status==='LOW'?'需重点核对':'待确认'):'截图未提供';label.append(tag);
  }
  if(parsed.image_recognition.blocked)for(const el of document.querySelectorAll('#transaction-form button[type=submit],#transaction-form [name=parsed_confirmed]'))el.disabled=true;
  const create=$('#image-create-community');if(create)create.onclick=async()=>{create.disabled=true;try{const c=await api('/communities',{community_name:$('#image-new-community').value.trim()});const select=$('#transaction-form [name=community_id]');select.add(new Option(c.community_name,c.id,true,true));$('#image-community-error').textContent='已建立并选中，请继续核对成交字段';}catch(e){$('#image-community-error').textContent=e.message;}finally{create.disabled=false;}};
 }
}
function readDataUrl(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error('无法读取图片，请重新选择'));reader.readAsDataURL(blob);});}
export async function prepareImage(file){
 if(!file||!['image/png','image/jpeg','image/webp'].includes(file.type))throw new Error('图片格式不支持，请使用PNG、JPG或WEBP');
 if(file.size>8*1024*1024)throw new Error('图片过大，请裁剪后上传（最大8MB）');
 if(!file.size)throw new Error('图片为空，请重新复制');
 let bitmap;try{bitmap=await createImageBitmap(file);}catch{throw new Error('图片损坏或无法读取，请换一张截图');}
 try{
  if(bitmap.width*bitmap.height>20000000)throw new Error('图片像素过大，请先裁剪到单套成交信息');
  // Keep original pixels for normal screenshots. Upscaling happens once in the OCR provider.
  const scale=Math.min(1,2000/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);
  const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
  const url=canvas.toDataURL('image/png');if(url.length>11200000)throw new Error('图片内容过大，请缩小截图范围');
  return {image:url.split(',')[1],preview_url:await readDataUrl(file),lowResolution:Math.min(bitmap.width,bitmap.height)<400};
 }finally{bitmap.close();}
}
async function recognizeFile(file){
 if(busy){toast('正在识别，请等待当前图片完成');return;}
 const ticket=++generation;lockForm(true);const status=$('#image-status');status.textContent='已检测到图片，正在读取图片……';
 try{
  const image=await prepareImage(file);if(ticket!==generation)return;
  status.textContent='正在识别文字并解析成交信息……';
  const result=await api('/recognition/image',{image:image.image});if(ticket!==generation||!$('#transaction-form'))return;
  if(image.lowResolution)result.warnings.unshift('图片分辨率较低，请重点核对数字，建议使用原始截图');
  lockForm(false);await applyResult({...result,preview_url:image.preview_url});
  $('#image-status').textContent=result.image_recognition.blocked?'未能生成可靠的单套成交草稿，请裁剪后重试':'识别完成，请核对 / 修正后保存';
 }catch(error){if(ticket===generation&&$('#image-status')){lockForm(false);$('#image-status').textContent=error.message;toast(error.message,true);}}
 finally{if(ticket===generation)busy=false;}
}
